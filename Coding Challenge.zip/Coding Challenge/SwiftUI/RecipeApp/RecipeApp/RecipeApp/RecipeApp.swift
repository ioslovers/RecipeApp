//
//  RecipeAppApp.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 29/3/2023.
//

import SwiftUI

@main
struct RecipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
