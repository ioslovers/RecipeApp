//
//  SwiftUIView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 31/3/2023.
//

import SwiftUI
import RecipeDomain

struct LazyGridView: View {
    let recipes: [Recipe] // Data to display in the cells
    
    var body: some View {
        ScrollView(.horizontal) {
            LazyHStack(spacing: 16) {
                ForEach(recipes, id: \.identifier) { recipe in
                    //CellView(recipe: recipe)
                        //.frame(width: 200, height: 200)
                }
            }
            .padding()
        }
        .frame(height: 250.0)
//        GeometryReader { geometry in
//            if geometry.size.width > geometry.size.height {
//                // Landscape mode: display 2 cells in one row and scroll vertically
//                ScrollView {
//                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
//                        ForEach(data, id: \.self) { item in
//                            CellView(item: item)
//                                .frame(maxWidth: 200, maxHeight: 200)
//                        }
//                    }
//                    .padding()
//                }
//            } else {
                // Portrait mode: scroll horizontally
//                ScrollView(.horizontal) {
//                    LazyHStack(spacing: 16) {
//                        ForEach(recipes, id: \.self) { recipe in
//                            CellView(recipe: recipe)
//                                .frame(width: 200, height: 200)
//                        }
//                    }
//                    .padding()
//                }
//                .frame(height: 250.0)
//            }
//        }
    }
}

struct CellView: View {
    let recipe: Recipe
    var body: some View {
        VStack {
            //ImageView(urlString: "https://www.coles.com.au\(recipe.dynamicThumbnail)")
//            if showImage {
//                ImageView(urlString: "https://www.coles.com.au/content/dam/coles/inspire-create/thumbnails/Tomato-and-bread-salad-480x288.jpg")
//            }
//            Image(uiImage: ImageCache.shared.image(for: URL(string: "https://www.coles.com.au\(recipe.dynamicThumbnail)")))
//                .resizable()
//                .aspectRatio(contentMode: .fit)
            if let url = URL(string: "https://www.coles.com.au\(recipe.dynamicThumbnail)") {
                AsyncImagePrimary(
                    url: url,
                    placeholder: { Text("Loading ...") },
                    image: { Image(uiImage: $0).resizable() }
                )
                .frame(width: 200, height: 150) // 2:3 aspect ratio
            }
            
            Text("\(recipe.dynamicTitle)")
        }.onAppear(
            
        )
//        RoundedRectangle(cornerRadius: 16)
//            .fill(Color.blue)
//            .frame(maxWidth: .infinity, maxHeight: .infinity)
//            .overlay(
//                ImageView(urlString: <#T##String#>)
//                Text("\(recipe.dynamicTitle)")
//            )
    }
}


struct ContentViewDemo_Previews: PreviewProvider {
    static var previews: some View {
        LazyGridView(recipes: [
                Recipe(
                    dynamicTitle: "Title",
                    dynamicDescription: "Description",
                    dynamicThumbnail: "https://www.coles.com",
                    dynamicThumbnailAlt: "image",
                    recipeDetails: RecipeDetails(
                        amountLabel: "amount",
                        amountNumber: 1,
                        prepLabel: "prepLabel",
                        prepTime: "prepTime",
                        prepNote: "prepNote",
                        cookingLabel: "cookingLabel",
                        cookingTime: "cookingTime",
                        cookTimeAsMinutes: 15,
                        prepTimeAsMinutes: 23
                    ),
                    ingredients: [Ingredient(ingredient: "ingredient")]
                )
            ])
    }
}
