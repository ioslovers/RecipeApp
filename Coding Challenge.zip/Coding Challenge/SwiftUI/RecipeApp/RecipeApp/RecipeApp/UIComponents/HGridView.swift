//
//  HGridView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 31/3/2023.
//

import SwiftUI

struct HGridView: View {
    let firstLable: String
    let firstValue: String
    let secondLable: String
    let secondValue: String
    let thirdLable: String
    let thirdValue: String
    var body: some View {
        VStack {
            Divider()
            HStack{
                VStack(alignment: .center, spacing: 4) {
                    Text(firstLable)
                        .font(.footnote)
                    Text(firstValue)
                        .font(.bold(.body)())
                        .foregroundColor(.black)
                }
                .inExpandingRectangle()
                .fixedSize(horizontal: false, vertical: true)
                Divider()
                    .frame(height: 40)
                VStack(alignment: .center, spacing: 4) {
                    Text(secondLable)
                        .font(.footnote)
                    Text(secondValue)
                        .font(.bold(.body)())
                        .foregroundColor(.black)
                }
                .inExpandingRectangle()
                .fixedSize(horizontal: false, vertical: true)
                Divider()
                    .frame(height: 40)
                VStack(alignment: .center, spacing: 4) {
                    Text(thirdLable)
                        .font(.footnote)
                    Text(thirdValue)
                        .font(.bold(.body)())
                        .foregroundColor(.black)
                }
                .inExpandingRectangle()
                .fixedSize(horizontal: false, vertical: true)
            }
            .frame(height: 64.0)
            Divider()
        }
    }
}

struct HGridView_Previews: PreviewProvider {
    static var previews: some View {
        HGridView(
            firstLable: "Serves",
            firstValue: "8",
            secondLable: "Preps",
            secondValue: "15m",
            thirdLable: "Cooking",
            thirdValue: "4h 30m"
        )
    }
}
