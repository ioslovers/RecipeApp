//
//  SwiftUIView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 31/3/2023.
//

import SwiftUI

struct LargeTitleView: View {
    let title: String
    var body: some View {
        Text(title)
            .foregroundColor(.black)
            .font(.largeTitle)
            .bold()
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        LargeTitleView(title: "Pork, fennel and sage ragu with polena")
    }
}
