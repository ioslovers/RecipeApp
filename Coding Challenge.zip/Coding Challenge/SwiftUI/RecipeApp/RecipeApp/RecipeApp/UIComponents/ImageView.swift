//
//  ImageView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 31/3/2023.
//

import SwiftUI

struct ImageView : View {
    let urlString: String
    var body: some View {
        AsyncImage(url: URL(string:urlString)) { phase in
            if let image = phase.image {
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }
            else if phase.error != nil { // 3
                // some kind of error appears
                Text("Unable to download the image this time")
                    .bold()
                    .font(.body)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)

            }
            else {
                // showing progress view as placeholder
                ProgressView()
                    .font(.largeTitle)
            }
        }.padding()
    }
}

struct ImageView_Previews: PreviewProvider {
    static var previews: some View {
        ImageView(
            urlString: "https://www.coles.com.au/content/dam/coles/inspire-create/thumbnails/Tomato-and-bread-salad-480x288.jpg"
        )
    }
}
