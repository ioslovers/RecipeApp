//
//  BodyView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 31/3/2023.
//

import SwiftUI

struct BodyView: View {
    let bodyString: String
    var body: some View {
        Text(bodyString)
            .foregroundColor(.black)
            .font(.body)
    }
}

struct BodyView_Previews: PreviewProvider {
    static var previews: some View {
        BodyView(bodyString: "Put your slow cooker to work and make this moutch-watring pork ragu. Served with fluffy polenta, it's a guaranteed crowd-pleaser.")
    }
}
