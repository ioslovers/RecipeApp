//
//  RecipesViewModel.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 29/3/2023.
//

import Foundation
import RecipeDomain
import Combine

class RecipesViewModel: ObservableObject {
    var cancellables = Set<AnyCancellable>()
    @Published var recipeModel: RecipeModel?
    @Published var recipe: Recipe?
    var source: RecipeSource?
//    @Published var images: [UIImage?] = []

    init(source: RecipeSource){
        self.source = source
    }

    func loadRecipes() {
        let input = RecipesInputSource(fileName: "recipesSample", fileExtension: "json")
        source?.parseJSON(input)
            .sink { completion in
                debugPrint(completion)
            } receiveValue: { [weak self] model in
                debugPrint(model)
                self?.recipeModel = model
                self?.recipe = model.recipes.first
//                let urlStrings = model.recipes.map {"https://www.coles.com.au\($0.dynamicThumbnail)"}
//                let imageUrls = urlStrings.compactMap {URL(string: $0)}
//                self?.loadImages(from: imageUrls)
            }.store(in: &cancellables)
    }
    
    func addDomainToPath(string: String) -> String {
        var domain = "https://www.coles.com.au"
        domain.append(string)
        return domain
    }
    
    func changeDetailPage(for url: URL) {
        let model = recipeModel?.recipes.filter {$0.dynamicThumbnail.contains(url.absoluteString)}.first
        recipe = model
        
    }
    
//    func loadImages(from urls: [URL]) {
//        Publishers.MergeMany(urls.map(ImageCache.shared.loadImage(from:)))
//            .collect()
//            .sink { _ in }
//            .store(in: &cancellables)
//    }
//
//    func image(for url: URL) -> UIImage? {
//        return ImageCache.shared.image(for: url)
//    }
}

struct RecipesInputSource: RecipeDataInputSource {
    typealias Response = RecipeModel
    var fileName: String
    var fileExtension: String

    init(fileName: String, fileExtension: String) {
        self.fileName = fileName
        self.fileExtension = fileExtension
    }

    func decode(_ data: Data) throws -> RecipeModel {
        let decoder = JSONDecoder()
        do {
            let model = try decoder.decode(Response.self, from: data)
            return model
        } catch {
            throw error
        }
    }
}
