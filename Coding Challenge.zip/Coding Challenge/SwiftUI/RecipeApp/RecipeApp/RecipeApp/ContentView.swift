//
//  ContentView.swift
//  RecipeApp
//
//  Created by Ashish Tripathi on 29/3/2023.
//

import SwiftUI
import RecipeDomain
let posters = [
    "/content/dam/coles/inspire-create/thumbnails/Tomato-and-bread-salad-480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/Pork-ragu-480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/Panzanella-salad-480x280.jpg",
    "/content/dam/coles/inspire-create/thumbnails/whats-for-dinner-live-thumbnails/Tasia-and-Gracia-Hainanese-Chicken-480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/cauliflower-soup--480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/Lamb-shank-ragu-with-pappardelle-480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/Lamb-and-hasselback-pumpkin-480x288.jpg",
    "/content/dam/coles/inspire-create/thumbnails/Gnocchi-with-pumpkin-and-whipped-ricotta-480x288.jpg"
].map { URL(string: "https://www.coles.com.au\($0)")! }

struct ContentView: View {
    @ObservedObject var viewModel = RecipesViewModel(
        source: RecipeDomain()
    )

    var body: some View {
        ScrollView{
            VStack {
                LargeTitleView(
                    title: viewModel.recipe?.dynamicTitle ?? ""
                )
            Spacer()
              .frame(height: 50)
                BodyView(
                    bodyString: viewModel.recipe?.dynamicDescription ?? ""
                )
            Spacer()
                .frame(height: 30)
                ImageView(
                    urlString:viewModel.addDomainToPath(
                        string: viewModel.recipe?.dynamicThumbnail ?? ""
                    )
                )
            HGridView(
                firstLable: viewModel.recipe?.recipeDetails.amountLabel ?? "",
                firstValue: String(viewModel.recipe?.recipeDetails.amountNumber ?? 0),
                secondLable: viewModel.recipe?.recipeDetails.prepLabel ?? "",
                secondValue: viewModel.recipe?.recipeDetails.prepTime ?? "",
                thirdLable: viewModel.recipe?.recipeDetails.cookingLabel ?? "",
                thirdValue: viewModel.recipe?.recipeDetails.cookingTime ?? ""
            )
            Text("Ingredients")
                .foregroundColor(.black)
                .font(.largeTitle)
                .bold()
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            ForEach(viewModel.recipe?.ingredients ?? [], id: \.self) {
                Text(">  \($0.ingredient)")
                    .font(.body)
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(8)
            }
        }
                .padding(16.0)
//            if let recipes = viewModel.recipeModel?.recipes {
//                ScrollView(.horizontal) {
//                    LazyHStack(spacing: 16) {
//                        ForEach(recipes, id: \.self) { recipe in
//                            if let url = URL(string: "https://www.coles.com.au\(recipe.dynamicThumbnail)") {
//                                VStack {
//                                    AsyncImagePrimary(
//                                        url: url,
//                                        placeholder: { Text("Loading ...") },
//                                        image: { Image(uiImage: $0).resizable() }
//                                    )
//                                    .frame(width: 200, height: 150) // 2:3 aspect ratio
//                                }
//                            }
//                        }
//                    }
//                    .padding()
//                }
//                .frame(height: 250.0)
//            }
            
//            if let recipes = viewModel.recipeModel?.recipes {
                ScrollView(.horizontal) {
                    LazyHStack(spacing: 16) {
                        ForEach(posters, id: \.self) { poster in
//                            if let url = URL(string: "https://www.coles.com.au\(recipe.dynamicThumbnail)") {
                            HCell(url: poster, text: "Lamb shank ragu with pappardelle").onTapGesture {
                                viewModel.changeDetailPage(for: poster)
                            }
//                            }
                        }
                    }
                    .padding()
                }
                .frame(height: 250.0)
//            }
            
//            if let recipes = viewModel.recipeModel?.recipes {
//                LazyGridView(recipes: recipes)
//                    .frame(height: 250)
//            }

    }
    .onAppear() {
        viewModel.loadRecipes()
    }
    }
}

struct HCell: View {
    let url: URL
    let text: String
    var body: some View {
        VStack {
            AsyncImagePrimary(
                url: url,
                placeholder: { Text("Loading ...") },
                image: { Image(uiImage: $0).resizable() }
            )
            .frame(width: 200, height: 150) // 2:3 aspect ratio
            Text("\(text)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

extension View {
    func inExpandingRectangle() -> some View {
        ZStack {
            Rectangle()
                .fill(Color.clear)
            self
        }
    }
}
