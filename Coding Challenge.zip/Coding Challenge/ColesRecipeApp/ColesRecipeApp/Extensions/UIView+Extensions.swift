import UIKit

extension UIView {

    // MARK: - Layout

    private func randomBorderColor() -> UIColor! {
        let h = CGFloat(arc4random()) / CGFloat(UInt32.max)
        let s = CGFloat(arc4random()) / CGFloat(UInt32.max)
        let b = CGFloat(arc4random()) / CGFloat(UInt32.max)
        return UIColor(hue: h, saturation: s, brightness: b, alpha: 1)
    }

    func outline(_ color: UIColor? = UIColor.black) {
        layer.borderColor = (color ?? randomBorderColor())?.cgColor
        layer.borderWidth = 1
    }

    func outlineAll() {
        outline()
        for view in subviews {
            view.outlineAll()
        }
    }

    // MARK: - CornerRadius

    static func cornerRadius() -> CGFloat {
        return 4
    }

    static func smallCornerRadius() -> CGFloat {
        return 2
    }

    func round(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }

    // MARK: - Hide and show

    @objc func hide() {
        isHidden = true
        alpha = 0
    }

    func showView(_ duration: TimeInterval = 0.5) {
        isHidden = false
        UIView.animate(withDuration: duration, animations: {
            self.alpha = 1
        }, completion: { _ in
            // This is needed in case a fadeOut animation overlaps with a call to this function
            if self.isHidden {
                self.isHidden = false
            }
        })
    }

    func showView(_ duration: TimeInterval = 0.5, completion: @escaping (() -> Void)) {
        isHidden = false
        alpha = 0
        UIView.animate(withDuration: duration, animations: {
            self.alpha = 1
        }, completion: { _ in
            completion()
        })
    }

    func fadeOut(_ duration: TimeInterval = 0.5) {
        UIView.animate(withDuration: duration, animations: {
            self.alpha = 0
        }, completion: { _ in
            self.isHidden = true
        })
    }

    func fadeOut(_ duration: TimeInterval = 0.5, completion: @escaping (() -> Void)) {
        UIView.animate(withDuration: duration, animations: {
            self.alpha = 0
        }, completion: { _ in
            completion()
        })
    }

    // MARK: - AutoLayout

    func removeSelfAndConstraintsFromSuperview() {
        if let superview = superview {
            constraints
                .filter { $0.firstItem === superview || $0.secondItem === superview }
                .forEach { $0.isActive = false }
        }

        removeFromSuperview()
    }

    func addSubViewWithConstraints(_ view: UIView) {
        view.translatesAutoresizingMaskIntoConstraints = false
        addSubview(view)
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|", options: [], metrics: nil, views: ["view": view]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|", options: [], metrics: nil, views: ["view": view]))
    }

    func addSubViewWithVerticalConstraints(_ view: UIView) {
        view.translatesAutoresizingMaskIntoConstraints = false
        addSubview(view)
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|", options: [], metrics: nil, views: ["view": view]))
    }

    func addSubViewWithHorizontalConstraints(_ view: UIView) {
        view.translatesAutoresizingMaskIntoConstraints = false
        addSubview(view)
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|", options: [], metrics: nil, views: ["view": view]))
    }

    func addSubViewWithConstraints(_ view: UIView, insets: UIEdgeInsets) {
        view.translatesAutoresizingMaskIntoConstraints = false
        addSubview(view)
        addConstraint(NSLayoutConstraint(item: view, attribute: .top, relatedBy: .equal, toItem: self, attribute: .top, multiplier: 1, constant: insets.top))
        addConstraint(NSLayoutConstraint(item: view, attribute: .leading, relatedBy: .equal, toItem: self, attribute: .leading, multiplier: 1, constant: insets.left))
        addConstraint(NSLayoutConstraint(item: view, attribute: .bottom, relatedBy: .equal, toItem: self, attribute: .bottom, multiplier: 1, constant: -insets.bottom))
        addConstraint(NSLayoutConstraint(item: view, attribute: .trailing, relatedBy: .equal, toItem: self, attribute: .trailing, multiplier: 1, constant: -insets.right))
    }

    func stackViewsVertically(_ views: [UIView], padding: CGFloat = 0) {
        var topView = self
        for view in views {
            view.translatesAutoresizingMaskIntoConstraints = false
            addSubview(view)

            let top = (topView == self) ? "|" : "[topView]-(padding@750)-"
            let bottom = view == views.last ? "-(0@750)-|" : ""

            // Vertical
            let verticalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "V:\(top)[view]\(bottom)",
                                                                     options: NSLayoutConstraint.FormatOptions(),
                                                                     metrics: ["padding": padding],
                                                                     views: ["view": view, "topView": topView])
            addConstraints(verticalConstraints)

            // Horizontal
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: ["view": view]))

            topView = view
        }
    }

    func stackViewsHorizontally(_ views: [UIView]) {
        var leadingView = self
        var leading: String

        for view in views {
            view.translatesAutoresizingMaskIntoConstraints = false
            addSubview(view)
            let trailing = (view == views.last) ? "-0@750-|" : ""

            if leadingView == self {
                leading = "|"
                addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:\(leading)[view]\(trailing)", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: ["view": view, "leadingView": leadingView]))
            } else {
                leading = "[leadingView]-(0@750)-"
                addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:\(leading)[view(==leadingView)]\(trailing)", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: ["view": view, "leadingView": leadingView]))
            }

            // Vertical constraints
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: ["view": view]))
            leadingView = view
        }
    }

    // MARK: - AutoLayout - Anchors

    // to fill an another view (inset is optional)
    func anchorAllSides(to view: UIView, with insets: UIEdgeInsets = .zero) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: view.topAnchor, constant: insets.top),
            leftAnchor.constraint(equalTo: view.leftAnchor, constant: insets.left),
            bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -insets.bottom),
            rightAnchor.constraint(equalTo: view.rightAnchor, constant: -insets.right)
        ])
    }

    // anchor height & width with same size to produce square layout
    func anchorSquare(size: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: size),
            heightAnchor.constraint(equalToConstant: size)
        ])
    }

    func anchorWidthHeight(to view: UIView, multiplier width: CGFloat = 1, multiplier height: CGFloat = 1) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: width),
            heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: height)
        ])
    }

    func anchorWidthHeight(value width: CGFloat = 1, value height: CGFloat = 1) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: width),
            heightAnchor.constraint(equalToConstant: height)
        ])
    }

    func anchorHeightNoWidth(to view: UIView, multiplier: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: multiplier),
            widthAnchor.constraint(equalToConstant: 1)
        ])
    }

    func anchorHeightNoWidth(with value: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            heightAnchor.constraint(equalToConstant: value),
            widthAnchor.constraint(equalToConstant: 1)
        ])
    }

    // MARK: - POP animations

    func showPopInAnimationXY(_ completion: (() -> Void)? = nil) {
        let alphaAnimation = CABasicAnimation(keyPath: "opacity")
        alphaAnimation.fromValue = 0
        alphaAnimation.toValue = 1
        alphaAnimation.duration = 0.2
        alphaAnimation.beginTime = (CACurrentMediaTime() + 0.1)

        let springAnimation = CABasicAnimation(keyPath: "transform.scale")
        springAnimation.toValue = 1.0
        springAnimation.fromValue = 0.5
        springAnimation.speed = 2.0
        springAnimation.beginTime = (CACurrentMediaTime() + 0.1)

        CATransaction.begin()
        layer.add(springAnimation, forKey: "SpringinessXY")
        layer.add(alphaAnimation, forKey: "AlphaAnimation")
        CATransaction.setCompletionBlock {
            self.alpha = 1
            completion?()
        }
        CATransaction.commit()
    }

    func showPopOutAnimationXY(_ completion: (() -> Void)? = nil) {
        let alphaAnimation = CABasicAnimation(keyPath: "opacity")
        alphaAnimation.fromValue = 1
        alphaAnimation.toValue = 0

        let springAnimation = CABasicAnimation(keyPath: "transform.scale")
        springAnimation.toValue = NSValue(cgPoint: CGPoint(x: 0.5, y: 0.5))
        springAnimation.fromValue = NSValue(cgPoint: CGPoint(x: 1.0, y: 1.0))
        springAnimation.speed = 2.0

        CATransaction.begin()
        layer.add(springAnimation, forKey: "SpringinessXY")
        layer.add(alphaAnimation, forKey: "AlphaAnimation")
        CATransaction.setCompletionBlock {
            self.alpha = 0
            completion?()
        }
        CATransaction.commit()
    }

    // MARK: - Shadows

    func addShadow() {
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: layer.cornerRadius)
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 2)
        layer.shadowRadius = 2
        layer.shadowOpacity = 0.1
        layer.shadowPath = shadowPath.cgPath
    }

    func addTopShadow() {
        addShadow()
        layer.shadowOffset = CGSize(width: 0, height: -2)
    }

    func animateShadowTo(bounds: CGRect, withDuration duration: CFTimeInterval) {
        guard let oldPath = layer.shadowPath, duration > 0 else { return }
        let newPath = UIBezierPath(roundedRect: bounds, cornerRadius: layer.cornerRadius).cgPath

        let animation = CABasicAnimation(keyPath: "shadowPath")
        animation.duration = duration
        animation.fromValue = oldPath
        animation.toValue = newPath
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        animation.isRemovedOnCompletion = true
        layer.add(animation, forKey: "shadowPath")

        layer.shadowPath = newPath
    }

    func addCardShadow() {
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: layer.cornerRadius)
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 1)
        layer.shadowRadius = 1
        layer.shadowOpacity = 0.1
        layer.shadowPath = shadowPath.cgPath
    }

    func addTooltipShadow() {
        layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.1).cgColor
        layer.shadowOffset = CGSize(width: 0, height: 1)
        layer.shadowOpacity = 1
        layer.shadowRadius = 1
    }

    func addRoundedShadow() {
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: bounds.width / 2)
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 2)
        layer.shadowRadius = 2
        layer.shadowOpacity = 0.1
        layer.shadowPath = shadowPath.cgPath
    }

    func getViewController() -> UIViewController? {
        if let nextResponder = next as? UIViewController {
            return nextResponder
        } else if let nextResponder = next as? UIView {
            return nextResponder.getViewController()
        } else {
            return nil
        }
    }
}
