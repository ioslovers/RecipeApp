//
//  UILabel.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit

extension UILabel {
    func setLabelBasicStyle(){
        numberOfLines = 0
        adjustsFontForContentSizeCategory = true
        translatesAutoresizingMaskIntoConstraints = false
    }
}
