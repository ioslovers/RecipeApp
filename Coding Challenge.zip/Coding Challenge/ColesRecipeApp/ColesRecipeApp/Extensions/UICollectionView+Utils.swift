//
//  Created by Razvan Balazs on 23/12/19.
//
//  Copyright © 2019 Qantas. All rights reserved.

import UIKit

extension UICollectionView {

    /// Registers a reusable view.
    /// - Parameters:
    ///   - viewType: UICollectionReusableView.
    ///   - kind: Header / Footer
    ///   - fromNib: Bool, True if the view is defined in a nib from current bundle. Default value: False
    func register<T: UICollectionReusableView>(_ viewType: T.Type, kind: String, fromNib: Bool = false) {
        let identifier = String(describing: viewType)
        if fromNib {
            let nib = UINib(nibName: identifier, bundle: nil)
            register(nib,
                     forSupplementaryViewOfKind: kind,
                     withReuseIdentifier: identifier)
        } else {
            register(viewType,
                     forSupplementaryViewOfKind: kind,
                     withReuseIdentifier: identifier)
        }
    }

    /// Registers a collection view cell.
    /// - Parameters:
    ///   - cellType: UICollectionViewCell type.
    ///   - fromNib: Bool, True if the view is defined in a nib from current bundle. Default value: False.
    func register<T: UICollectionViewCell>(_ cellType: T.Type, fromNib: Bool = false) {
        let identifier = String(describing: cellType)
        let nib = UINib(nibName: identifier, bundle: nil)
        if fromNib {
            register(nib, forCellWithReuseIdentifier: identifier)
        } else {
            register(cellType, forCellWithReuseIdentifier: identifier)
        }
    }

    /// Dequeues a registered reusable view.
    /// - Parameters:
    ///   - viewType: UICollectionReusableView type.
    ///   - kind: - kind: Header / Footer
    ///   - indexPath: IndexPath
    func dequeReusableView<T: UICollectionReusableView>(_ viewType: T.Type, kind: String, for indexPath: IndexPath) -> T {
          let identifier = String(describing: viewType)
          guard let view = dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: identifier, for: indexPath) as? T else {
              fatalError("Could not dequeue Section Header Footer View with identifier: \(identifier)")
          }
          return view
      }

    /// Dequeues a registered cell
    /// - Parameter cellType: UICollectionViewCell type.
    func dequeue<T: UICollectionViewCell>(_ cellType: T.Type, for indexPath: IndexPath) -> T {
        let identifier = String(describing: cellType)
        guard let cell = dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as? T else {
               fatalError("Could not dequeue cell with identifier: \(identifier)")
           }
           return cell
       }
}
