import Foundation
import UIKit

public extension UIView {

    // MARK: Manual Layout

    internal var centerX: CGFloat {
        get {
            return self.center.x
        }
        set {
            self.center = CGPoint(x: newValue, y: self.center.y)
        }
    }

    internal var centerY: CGFloat {
        get {
            return self.center.y
        }
        set {
            self.center = CGPoint(x: self.center.x, y: newValue)
        }
    }

    @objc internal var width: CGFloat {
        get {
            return self.frame.size.width
        }
        set {
            self.frame.size.width = newValue
        }
    }

    @objc internal var height: CGFloat {
        get {
            return self.frame.size.height
        }
        set {
            self.frame.size.height = newValue
        }
    }

    internal var size: CGSize {
        get {
            return self.frame.size
        }
        set {
            self.frame.size = newValue
        }
    }

    internal var origin: CGPoint {
        get {
            return self.frame.origin
        }
        set {
            self.frame.origin = newValue
        }
    }

    internal var top: CGFloat {
        get {
            return self.frame.origin.y
        }
        set {

            self.frame.origin.y = newValue
        }
    }

    internal var bottom: CGFloat {
        get {
            return (self.frame.origin.y + self.frame.size.height)
        }
        set {
            self.frame.origin.y = (newValue - self.frame.size.height)
        }
    }

    internal var left: CGFloat {
        get {
            return self.frame.origin.x
        }
        set {
            self.frame.origin.x = newValue
        }
    }

    internal var right: CGFloat {
        get {
            return (self.frame.origin.x + self.frame.size.width)
        }
        set {
            self.frame.origin.x = (newValue - self.frame.size.width)
        }
    }

    internal func centerHorizontally() {
        if self.superview != nil {
            self.left = floor((self.superview!.width / 2) - (self.width / 2))
        }
    }

    internal func centerVertically() {
        if self.superview != nil {
            self.top = floor((self.superview!.height / 2) - (self.height / 2))
        }
    }

    internal func centerInSuperview() {
        if self.superview != nil {
            self.centerVertically()
            self.centerHorizontally()
        }
    }

    internal var borderWidth: CGFloat {
        get {
            return self.layer.borderWidth
        }
        set {
            self.layer.borderWidth = newValue
        }
    }

    internal var borderColor: UIColor {
        get {
            if let cgColor = self.layer.borderColor {
                return UIColor(cgColor: cgColor)
            }
            return UIColor.black
        }
        set {
            self.layer.borderColor = newValue.cgColor
        }
    }

    /// The view layers corner radius
    internal var cornerRadius: CGFloat {
        get {
            return self.layer.cornerRadius
        }
        set {
            self.layer.cornerRadius  = newValue
        }
    }

    // MARK: Autolayout

    internal func pinToRight(ofView view: UIView, padding: CGFloat) {
        self.translatesAutoresizingMaskIntoConstraints = false
        if !view.subviews.contains(self) { view.addSubview(self) }
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": self]))
    }

    internal func pinToLeft(ofView view: UIView, padding: CGFloat) {
        self.translatesAutoresizingMaskIntoConstraints = false
        if !view.subviews.contains(self) { view.addSubview(self) }
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(\(padding))-[view]-|", options: [], metrics: nil, views: ["view": self]))
    }

    internal func pinToTop(ofView view: UIView, padding: CGFloat) {
        self.translatesAutoresizingMaskIntoConstraints = false
        if !view.subviews.contains(self) { view.addSubview(self) }
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(\(padding))-[view]-|", options: [], metrics: nil, views: ["view": self]))
    }

    internal func pinToBottom(ofView view: UIView, padding: CGFloat) {
        self.translatesAutoresizingMaskIntoConstraints = false
        if !view.subviews.contains(self) { view.addSubview(self) }
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": self]))
    }

    // MARK: Autolayout edges

    internal func addSubviewWithConstraints(_ view: UIView, insets: UIEdgeInsets = UIEdgeInsets.zero) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(\(insets.left))-[view]-(\(insets.right))-|", options: [], metrics: nil, views: ["view": view]))
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(\(insets.top))-[view]-(\(insets.bottom))-|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addSubviewWithVerticalConstraints(_ view: UIView, padding: CGFloat = 0) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(\(padding))-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addSubviewWithHorizontalConstraints(_ view: UIView, padding: CGFloat = 0) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(\(padding))-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func insertSubviewWithConstraints(_ view: UIView, atIndex index: Int, insets: UIEdgeInsets = UIEdgeInsets.zero) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.insertSubview(view, at: index)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(\(insets.left))-[view]-(\(insets.right))-|", options: [], metrics: nil, views: ["view": view]))
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(\(insets.top))-[view]-(\(insets.bottom))-|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func insertSubviewWithVerticalConstraints(_ view: UIView, atIndex index: Int, padding: CGFloat = 0) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.insertSubview(view, at: index)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(\(padding))-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func insertSubviewWithHorizontalConstraints(_ view: UIView, atIndex index: Int, padding: CGFloat = 0) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.insertSubview(view, at: index)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(\(padding))-[view]-(\(padding))-|", options: [], metrics: nil, views: ["view": view]))
    }

    // MARK: Autolayout sizing

    internal func addSubviewWithHeight(_ view: UIView, height: CGFloat) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[view(==\(height))]", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addSubviewWithWidth(_ view: UIView, width: CGFloat) {
        view.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(view)
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[view(==\(width))]", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addHeightConstraint(toView view: UIView, height: CGFloat) {
        view.translatesAutoresizingMaskIntoConstraints = false
        if !self.subviews.contains(view) { self.addSubview(view) }
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[view(==\(height))]", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addWidthConstraint(toView view: UIView, width: CGFloat) {
        view.translatesAutoresizingMaskIntoConstraints = false
        if !self.subviews.contains(view) { self.addSubview(view) }
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:[view(==\(width))]", options: [], metrics: nil, views: ["view": view]))
    }

    // MARK: Autolayout subviews

    internal func addFullHeightConstraint(toSubview view: UIView) {
        view.translatesAutoresizingMaskIntoConstraints = false
        if !self.subviews.contains(view) { self.addSubview(view) }
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|", options: [], metrics: nil, views: ["view": view]))
    }

    internal func addFullWidthConstraint(toSubview view: UIView) {
        view.translatesAutoresizingMaskIntoConstraints = false
        if !self.subviews.contains(view) { self.addSubview(view) }
        self.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|", options: [], metrics: nil, views: ["view": view]))
    }

    // MARK: - Loading

    /// Returns the expected nib name of `view`.
    static var nibName: String {
        return String(describing: self)
    }

    /// Returns the nib for the `view`.
    static var nib: UINib? {
        let bundle = Bundle(for: self)
        guard bundle.path(forResource: nibName, ofType: "nib") != nil else { return nil }
        return UINib(nibName: nibName, bundle: bundle)
    }

    private static func instantiateFromNib<T: UIView>(nibNameOrNil: String? = nil) -> T? {
        let name: String
        if let nibName = nibNameOrNil {
            name = nibName
        } else {
            // Most nibs are demangled by practice, if not, just declare string explicitly
            name = "\(self.nibName)".components(separatedBy: ".").last!
        }
        let bundle = Bundle(for: self)
        guard bundle.path(forResource: name, ofType: "nib") != nil else { return nil }
        let nib = UINib(nibName: name, bundle: bundle)
        return nib.instantiate(withOwner: self, options: nil).first as? T
    }

    /// Convenience helper to create a `view` from it's associated xib if available.
    /// This method can infer the type based on the caller.
    ///
    /// - Parameter nibNameOrNil: The name of the nib to create a `view` from.
    /// - Returns: The `view` created from the associated xib or xib name specified.
    static func fromNib(nibNameOrNil: String? = nil) -> Self? {
        return instantiateFromNib(nibNameOrNil: nibNameOrNil)
    }
}
