//
//  RecipeViewController.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import UIKit
import RecipeDomain

enum TableViewCells: String {
    case RecipeDetailsView
    case HorizontalPrepView
    case ItemListView
    case SmartCarouselTableViewCell
}

struct RecipeViewControllerSource {
    let tableSource: [TableViewSource]
}

struct TableViewSource {
    let section: Int
    let identifier: TableViewCells.RawValue
}

let source1 = TableViewSource(section: 0, identifier: TableViewCells.RecipeDetailsView.rawValue)
let source2 = TableViewSource(section: 1, identifier: TableViewCells.HorizontalPrepView.rawValue)
let source3 = TableViewSource(section: 2, identifier: TableViewCells.ItemListView.rawValue)
let source4 = TableViewSource(section: 3, identifier: TableViewCells.SmartCarouselTableViewCell.rawValue)

let allSourcesForPort = RecipeViewControllerSource(tableSource: [source1, source2, source3, source4])
let allSourcesForLandscape = RecipeViewControllerSource(tableSource: [source4])

class RecipeViewController: UIViewController, ViewPublisher {
    @IBOutlet weak var tableView: UITableView!

    private var recipeViewControllerSource: RecipeViewControllerSource = allSourcesForPort
    private let viewModel = RecipesViewModel(source: RecipeDomain())
    private var tableViewSource: RecipeViewControllerSource?
    private var recipeDetailView: RecipeDetailsCell!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        viewModel.delegate = self
        viewModel.loadRecipes()
    }

    override func viewDidLayoutSubviews() {
        if UIDevice.current.orientation.isPortrait {
            recipeViewControllerSource = allSourcesForPort
        } else if UIDevice.current.orientation.isLandscape {
            recipeViewControllerSource = allSourcesForLandscape
        }
        tableView.reloadData()
    }

    func setupView() {
        tableView.separatorColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        let recipeDetailsView = UINib.init(
            nibName: "RecipeDetailsCell",
            bundle: Bundle(for: RecipeDetailsCell.self)
        )
        tableView.register(
            recipeDetailsView,
            forCellReuseIdentifier: "RecipeDetailsCell"
        )
        
        let horizontalPrepView = UINib.init(
            nibName: "HorizontalPrepView",
            bundle: Bundle(for: HorizontalPrepView.self)
        )
        tableView.register(
            horizontalPrepView,
            forCellReuseIdentifier: "HorizontalPrepView"
        )
        
        let itemListView = UINib.init(
            nibName: "ItemListCell",
            bundle: Bundle(for: ItemListCell.self)
        )
        tableView.register(
            itemListView,
            forCellReuseIdentifier: "ItemListCell"
        )
        
        let gridTableViewCell = UINib.init(
            nibName: "GridTableViewCell",
            bundle: Bundle(for: GridTableViewCell.self)
        )
        tableView.register(
            gridTableViewCell,
            forCellReuseIdentifier: "GridTableViewCell"
        )
        
        let smartCarouselTableViewCell = UINib.init(
            nibName: "SmartCarouselTableViewCell",
            bundle: Bundle(for: SmartCarouselTableViewCell.self)
        )
        tableView.register(
            smartCarouselTableViewCell,
            forCellReuseIdentifier: "SmartCarouselTableViewCell"
        )
    }

    func reloadViewWithModel() {
        tableView.reloadData()
    }
}

extension RecipeViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        recipeViewControllerSource.tableSource.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier: TableViewCells = TableViewCells(
            rawValue: recipeViewControllerSource.tableSource[indexPath.section].identifier
        ) ?? .SmartCarouselTableViewCell
        
        switch identifier {
        case .RecipeDetailsView:
            let recipeDetailsViewcell = tableView.dequeueReusableCell(
                withIdentifier: "RecipeDetailsCell", for: indexPath
            ) as! RecipeDetailsCell
            if let recipe = viewModel.recipeModel?.recipes.filter({ $0.isSelected == true }).first {
                recipeDetailsViewcell.bind(
                    source: RecipeDetailViewValue(recipe: recipe)
                )
            }
            return recipeDetailsViewcell
        case .HorizontalPrepView:
            let horizontalPrepViewcell = tableView.dequeueReusableCell(
                withIdentifier: "HorizontalPrepView", for: indexPath
            ) as! HorizontalPrepView
            if let recipe = viewModel.recipeModel?.recipes.filter( { $0.isSelected == true } ).first {
                horizontalPrepViewcell.bind(
                    recipeDetail: recipe.recipeDetails
                )
            }
            return horizontalPrepViewcell
        case .ItemListView:
            let itemListViewcell = tableView.dequeueReusableCell(
                withIdentifier: "ItemListCell", for: indexPath
            ) as! ItemListCell
            if let recipe = viewModel.recipeModel?.recipes.filter( { $0.isSelected == true } ).first {
                itemListViewcell.bind(
                    source: ItemListValues(list: recipe.ingredients)
                )
            }
            return itemListViewcell
        case .SmartCarouselTableViewCell:
            let gridTableViewCell = tableView.dequeueReusableCell(
                withIdentifier: "SmartCarouselTableViewCell", for: indexPath
            ) as! SmartCarouselTableViewCell
            gridTableViewCell.configure(recipes: viewModel.recipeModel?.recipes)
//            gridTableViewCell.delegate = self
            return gridTableViewCell
        }
    }
}

extension RecipeViewController: GridTableViewCellDelegate {
    func selectedIndexOfRecipe(index: Int) {
        viewModel.selectedIndexOfRecipe(index: index)
        tableView.scrollToRow(
            at: IndexPath(row: 0, section: 0),
            at: .top,
            animated: true
        )
    }
}

struct RecipeDetailViewValue: RecipeDetailsDataSource {
    var recipe: Recipe
}
