//
//  HorizontalCollectionViewCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 02/4/2023.
//

import UIKit
import Theme

protocol HorizontalCollectionViewDataSource {
    var title: String { get set}
    var description: String { get set}
    var imageUrl: String { get set}
}

class HorizontalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        setupStyle()
    }

    func setupStyle() {
        titleLabel.textColor = Theme.appearance.color.basicColor.body
        descriptionLabel.textColor = Theme.appearance.color.basicColor.description
        
        titleLabel.font = Theme.appearance.font.basicFont.body
        descriptionLabel.font = Theme.appearance.font.basicFont.body
        
        titleLabel.setLabelBasicStyle()
        descriptionLabel.setLabelBasicStyle()
    }

    func bind(source: HorizontalCollectionViewDataSource) {
        imageView.loadThumbnail(urlSting: source.imageUrl)
        titleLabel.text = NSLocalizedString("RECIPE", comment: "")
        descriptionLabel.text = source.title
    }
}
