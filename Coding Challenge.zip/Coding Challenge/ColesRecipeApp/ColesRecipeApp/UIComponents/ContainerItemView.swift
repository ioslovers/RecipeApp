//
//  Created by animesh.d.mishra on 2/9/2022.
//
//  Copyright © 2022 Qantas. All rights reserved.

import UIKit

class ContainerItemView: UIView {
    struct Constants {
        static let defaultWidth = 156.0
    }

    @IBOutlet private weak var imageContainerView: UIView!
    @IBOutlet private weak var carouselImageView: UIImageView!
    @IBOutlet private weak var newTagView: UIView!
    @IBOutlet private weak var newTagLabel: UILabel!
    @IBOutlet private weak var overlayView: UIView!
    @IBOutlet weak var contentName: UILabel!
    @IBOutlet weak var contentNameViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var contentNameContainer: UIView!
    @IBOutlet weak var textOverlayView: UIView!

    @IBOutlet weak var componentWidth: NSLayoutConstraint!

    var selectedBackgroundColor: UIColor {
        return .gray
    }

    func setupView(with brand: HorizontalCollectionViewDataSource, width: CGFloat? = Constants.defaultWidth) {
        setupMerchantCard(with: brand)
        
        if let width = width {
            componentWidth.constant = (width != 0) ? width : Constants.defaultWidth
        } else {
            componentWidth.constant = Constants.defaultWidth
        }

//        self.delegate = delegate
        configureAccessibility()
    }

    private func setupMerchantCard(with brand: HorizontalCollectionViewDataSource) {
        if let url = URL(string: brand.title) {
//            carouselImageView.setImage(with: url, placeholderImage: UIImage())
        }
    }

    private func configureAccessibility() {
        isAccessibilityElement = true
//        accessibilityLabel = merchantCard?.accessibilityText
        accessibilityTraits = .button
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
//        overlayView.backgroundColor = .lightOverlay
//        textOverlayView.backgroundColor = .lightOverlay
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        overlayView.backgroundColor = .clear
        textOverlayView.backgroundColor = .clear
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesCancelled(touches, with: event)
        overlayView.backgroundColor = .clear
        textOverlayView.backgroundColor = .clear
    }
}
