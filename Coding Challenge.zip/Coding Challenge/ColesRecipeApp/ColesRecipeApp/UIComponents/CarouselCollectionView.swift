//
//  CarouselCollectionView.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import UIKit

class CarouselCollectionView: UICollectionView {
    
    private let cells: [UICollectionViewCell.Type] = [
        UICollectionViewCell.self,
        MerchantCardCarouselItemCell.self
    ]
    
//    var components: [Component] = [] {
//        didSet {
//            flowLayout.components = components
//        }
//    }
    
    let flowLayout: CarouselComponentFlowLayout = {
        let layout = CarouselComponentFlowLayout()
        layout.scrollDirection = .horizontal
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        return layout
    }()
    
    private let trailingSpacing: CGFloat = 48
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionViewLayout = flowLayout
        backgroundColor = .white
        isAccessibilityElement = false
        shouldGroupAccessibilityChildren = true
        
//        contentInset = UIEdgeInsets.only(right: trailingSpacing)
        contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 48.0)
        cells.forEach({ self.register($0.self, forCellWithReuseIdentifier: "CollectionViewCell") })
    }
    
    override var contentSize: CGSize {
        didSet {
            invalidateIntrinsicContentSize()
        }
    }
    
    override var intrinsicContentSize: CGSize {
        contentSize
    }
}

class CarouselComponentFlowLayout: UICollectionViewFlowLayout {
    
    private var contentHeight: CGFloat = 0
    
//    var components: [Component] = []
    
    override var collectionViewContentSize: CGSize {
        let width = super.collectionViewContentSize.width
        return CGSize(width: width, height: contentHeight)
    }
    
    override func prepare() {
        super.prepare()
        contentHeight = 0
    }
    
    // we can customize layout for each component here
    // default it is aligned top
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        let attributes = super.layoutAttributesForElements(in: rect)
        var visibleLayoutAttributes = [UICollectionViewLayoutAttributes]()
        for element in attributes ?? [] {
            if element.representedElementCategory == .cell {
                let index = element.indexPath.section
                
//                if shouldAlignToTop(index) {
//                    element.frame.origin.y = 0
//                    contentHeight = max(contentHeight, element.frame.height)
//                }
            }
            
            visibleLayoutAttributes.append(element)
        }
        
        return visibleLayoutAttributes
    }
    
//    private func shouldAlignToTop(_ index: Int) -> Bool {
//        guard components.indices.contains(index) else { return false }
//        let component = components[index]
//        return component.type != .linkCard
//    }
}

