//
//  Created by animesh.d.mishra on 26/10/2022.
//
//  Copyright © 2022 Qantas. All rights reserved.

import UIKit

class SmartCarouselComponentView: UIView, UICollectionViewDelegate, UICollectionViewDataSource,
                                UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: CarouselCollectionView!

//    weak var delegate: CarouselDelegate?

    struct Constants {
        static let cellSpacing: CGFloat = 12
        static let trailingSpacing: CGFloat = 48
    }

    var itemWidth = 0.0

//    var items: [Component] = [] {
//        didSet {
//            items.sort(by: { $0.sortOrder < $1.sortOrder })
//            collectionView.components = items
//            collectionView.reloadData()
//            collectionView.layoutIfNeeded()
//        }
//    }

    private var leadingInset: CGFloat {
        guard traitCollection.horizontalSizeClass == .regular && traitCollection.verticalSizeClass == .regular else {
            return 16
        }

        return 32
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        let smartCarouselTableViewCell = UINib.init(
            nibName: "MerchantCardCarouselItemCell",
            bundle: Bundle(for: MerchantCardCarouselItemCell.self)
        )
        collectionView.register(
            smartCarouselTableViewCell,
            forCellWithReuseIdentifier: "MerchantCardCarouselItemCell"
        )
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    func prepareForReuse() {
//        items.removeAll()
    }

//    func carouselItem(_ view: CarouselItemView, didSelect component: CarouselItemComponent) {
//        delegate?.carouselItem(didSelect: view, component: component)
//    }

//    func doubleCarouselItem(_ view: CarouselItemView, didSelect component: Component) {
//        delegate?.doubleCarouselItem(didSelect: view, component: component)
//    }

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let currentComponent = items[indexPath.section]
//
        var cell: MerchantCardCarouselItemCell?
//        var component: CarouselItemComponent?
//
//        switch currentComponent {
//        case let .listContainer(cards):
//            cell = collectionView.dequeue(ListContainerCell.self, for: indexPath)
//            component = cards
//        case let .merchantCard(merchantCard):
            cell = collectionView.dequeue(MerchantCardCarouselItemCell.self, for: indexPath)
//            component = merchantCard
//        case let .linkCard(linkCard):
//            cell = collectionView.dequeue(LinkCardCarouselItemCell.self, for: indexPath)
//            component = linkCard
//        default:
//            break
//        }

        if let cell = cell {
            cell.configure(componentWidth: itemWidth)
            cell.configure()
            return cell
        }

        return collectionView.dequeue(UICollectionViewCell.self, for: indexPath)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        guard section != 0 else {
            return UIEdgeInsets(top: 0, left: leadingInset, bottom: 0, right: 0)
        }
        return UIEdgeInsets(top: 0, left: Constants.cellSpacing, bottom: 0, right: 0)
    }
}

// MARK: - UIAccessibilityContainer

extension SmartCarouselComponentView {
    override func accessibilityElementCount() -> Int {
        return 10
    }

    override func accessibilityElement(at index: Int) -> Any? {
        return collectionView.cellForItem(at: IndexPath(item: 0, section: index))
    }
}
