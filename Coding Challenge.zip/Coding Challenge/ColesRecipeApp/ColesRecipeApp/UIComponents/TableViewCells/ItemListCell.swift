//
//  IngredientsListView.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import UIKit
import Theme

protocol ItemListDataSource {
    var itemList: [String]? { get set }
}

class ItemListCell: UITableViewCell {
    @IBOutlet weak var itemHeaderLabel: UILabel!
    @IBOutlet weak var itemStackView: UIStackView!
    
    // MARK: - Initialization
    override public func awakeFromNib() {
        super.awakeFromNib()
        setStyle()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setStyle() {
        itemHeaderLabel.font = Theme.appearance.font.basicFont.title
        itemHeaderLabel.textColor = Theme.appearance.color.basicColor.title
    }
    
    func bind(source: ItemListDataSource) {
        itemHeaderLabel.text = NSLocalizedString("Ingredients", comment: "")
        itemStackView.subviews.forEach { $0.removeFromSuperview() }

        let labels = source.itemList?.compactMap {
            let aLabel = UILabel(frame: .zero)
            aLabel.textColor = Theme.appearance.color.basicColor.description
            aLabel.font = Theme.appearance.font.basicFont.body
            aLabel.numberOfLines = 0
            aLabel.adjustsFontForContentSizeCategory = true
            aLabel.translatesAutoresizingMaskIntoConstraints = false
            aLabel.setContentHuggingPriority(.required, for: .vertical)
            aLabel.text = ">  \($0)"
            return aLabel
        }

        labels?.forEach {
            itemStackView.addArrangedSubview($0)
        }
    }
}
