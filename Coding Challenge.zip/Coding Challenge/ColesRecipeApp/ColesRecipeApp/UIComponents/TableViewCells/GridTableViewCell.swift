//
//  HGridTableViewCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import UIKit
import RecipeDomain

protocol GridTableViewCellDelegate: AnyObject {
    func selectedIndexOfRecipe(index: Int)
}

class GridTableViewCell: UITableViewCell {
    @IBOutlet weak var collectionView: UICollectionView!
    weak var delegate: GridTableViewCellDelegate?
    private var recipes: [Recipe]?

    override func awakeFromNib() {
        super.awakeFromNib()
        registerCell()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = GridCollectionViewFlowLayout()
    }
    
    func registerCell() {
        collectionView.register(
            UINib(
                nibName:"HorizontalCollectionViewCell",
                bundle: nil
            ),forCellWithReuseIdentifier: "HorizontalCollectionViewCell"
        )
    }
    
    func bind(recipes: [Recipe]?) {
        self.recipes = recipes
        collectionView.reloadData()
    }
}

extension GridTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(
        _ collectionView: UICollectionView,
        numberOfItemsInSection section: Int
    ) -> Int {
        recipes?.count ?? 0
    }
    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "HorizontalCollectionViewCell",
            for: indexPath) as! HorizontalCollectionViewCell
        if let recipe = recipes?[indexPath.row] {
            cell.bind(source: HorizontalCollectionViewDataValue(recipe: recipe))
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.selectedIndexOfRecipe(index: indexPath.row)
    }
}

struct HorizontalCollectionViewDataValue: HorizontalCollectionViewDataSource {
    var title: String
    var description: String
    var imageUrl: String
    init(recipe: Recipe) {
        self.title = recipe.dynamicTitle
        self.description = recipe.dynamicDescription
        self.imageUrl = recipe.dynamicThumbnail.domainString
    }
}

class GridCollectionViewFlowLayout: UICollectionViewFlowLayout {
    override init() {
        super.init()
        self.setupFlowLayout()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setupFlowLayout()
    }

    func setupFlowLayout() {
        self.scrollDirection = .horizontal
        self.itemSize = CGSize(width: 240, height: 270)
        self.minimumLineSpacing = 10
    }
}
