//
//  RecipeDetailsCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import UIKit
import RecipeDomain
import Theme

protocol RecipeDetailsDataSource {
    var recipe: Recipe { get set }
}

class RecipeDetailsCell: UITableViewCell {
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var recipeImageView: UIImageView!

    // MARK: - Initialization
    override public func awakeFromNib() {
        super.awakeFromNib()
        setStyle()
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    func setStyle() {
        headingLabel.textColor = Theme.appearance.color.basicColor.title
        descriptionLabel.textColor = Theme.appearance.color.basicColor.description
        
        descriptionLabel.font = Theme.appearance.font.basicFont.body
        descriptionLabel.setLabelBasicStyle()
        
        headingLabel.font = Theme.appearance.font.basicFont.title
        headingLabel.setLabelBasicStyle()
    }
    
    func bind(source: RecipeDetailsDataSource) {
        headingLabel.text = source.recipe.dynamicTitle
        descriptionLabel.text = source.recipe.dynamicDescription
        recipeImageView.loadThumbnail(urlSting: source.recipe.dynamicThumbnail.domainString)
    }
}
struct ItemListValues: ItemListDataSource {
    var itemList: [String]? = []
    init(list: [Ingredient]) {
        list.forEach { item in
            self.itemList?.append(item.ingredient)
        }
    }
}
