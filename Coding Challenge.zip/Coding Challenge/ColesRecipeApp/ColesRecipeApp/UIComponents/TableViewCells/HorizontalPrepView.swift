//
//  HorizontalPrepView.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import UIKit
import RecipeDomain
import Theme

class HorizontalPrepView: UITableViewCell {
    @IBOutlet weak var firstTitleLabel: UILabel!
    @IBOutlet weak var firstValueLabel: UILabel!
    @IBOutlet weak var secondTitleLabel: UILabel!
    @IBOutlet weak var secondValueLabel: UILabel!
    @IBOutlet weak var thirdTitleLabel: UILabel!
    @IBOutlet weak var thirdValueLabel: UILabel!
    
    // MARK: - Initialization
    override public func awakeFromNib() {
        super.awakeFromNib()
        setupStyle()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setupStyle() {
        firstTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        secondTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        thirdTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        
        firstValueLabel.textColor = Theme.appearance.color.basicColor.description
        secondValueLabel.textColor = Theme.appearance.color.basicColor.description
        thirdValueLabel.textColor = Theme.appearance.color.basicColor.description
        
        firstTitleLabel.font = Theme.appearance.font.basicFont.body
        secondTitleLabel.font = Theme.appearance.font.basicFont.body
        thirdTitleLabel.font = Theme.appearance.font.basicFont.body
        
        firstValueLabel.font = Theme.appearance.font.basicFont.subtitle
        secondValueLabel.font = Theme.appearance.font.basicFont.subtitle
        thirdValueLabel.font = Theme.appearance.font.basicFont.subtitle
        
//        firstTitleLabel.setLabelBasicStyle()
//        firstValueLabel.setLabelBasicStyle()
//        secondTitleLabel.setLabelBasicStyle()
//        secondValueLabel.setLabelBasicStyle()
//        thirdTitleLabel.setLabelBasicStyle()
//        thirdValueLabel.setLabelBasicStyle()
        
    }

    func bind(recipeDetail: RecipeDetails) {
        firstTitleLabel.text = recipeDetail.amountLabel
        firstValueLabel.text = "\(recipeDetail.amountNumber)"
        secondTitleLabel.text = recipeDetail.prepLabel
        secondValueLabel.text = recipeDetail.prepTime
        thirdTitleLabel.text = recipeDetail.cookingLabel
        thirdValueLabel.text = recipeDetail.cookingTime
    }
}
