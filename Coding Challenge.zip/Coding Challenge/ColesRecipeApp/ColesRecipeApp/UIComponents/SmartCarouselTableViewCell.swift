//
//  Created by animesh.d.mishra on 26/10/2022.
//
//  Copyright © 2022 Qantas. All rights reserved.

import UIKit
import RecipeDomain

class SmartCarouselTableViewCell: UITableViewCell {

    @IBOutlet weak var smartCarouselContainerView: UIView!
    private var recipes: [Recipe]?

    private var carouselView: SmartCarouselComponentView!

    func configure(recipes: [Recipe]?) {
        //Configure cell
        self.recipes = recipes

//        guard let carouselModel = model as? SmartCarousel else { return }
//
        if carouselView == nil {
            carouselView = SmartCarouselComponentView.fromNib()
            smartCarouselContainerView.addSubViewWithConstraints(carouselView)
        }
//
//        if let itemWidth = carouselModel.itemWidth {
//            carouselView.itemWidth = itemWidth
//        }
//
//        if let items = carouselModel.items {
//            carouselView.items = items
//        }
//
//        carouselView.delegate = self
//        self.delegate = delegate
    }

//    func carouselItem(didSelect itemView: CarouselItemView, component: CarouselItemComponent) {
//        guard let action = component.action else { return }
//        delegate?.performAction(action: action)
//    }
//
//    func doubleCarouselItem(didSelect itemView: CarouselItemView, component: Component) {
//        switch component {
//        case let .merchantCard(cards):
//            guard let action = cards.action else { return }
//            delegate?.performAction(action: action)
//        default:
//            break
//        }
//    }

    override func prepareForReuse() {
        super.prepareForReuse()
        carouselView.prepareForReuse()
    }
}
