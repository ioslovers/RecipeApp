//
//  Created by animesh.d.mishra on 29/9/2022.
//
//  Copyright © 2022 Qantas. All rights reserved.

import UIKit

class MerchantCardCarouselItemCell: UICollectionViewCell {

    private var promoComponentView: HorizontalCollectionViewCell!
    private var componentWidth: CGFloat?

    func configure() {
        if promoComponentView == nil {
            promoComponentView = HorizontalCollectionViewCell.fromNib()
        }
        
        addSubViewWithConstraints(promoComponentView)
    }

    func configureAccessibility() {
        isAccessibilityElement = false
    }

    func configure(componentWidth: CGFloat?) {
        self.componentWidth = componentWidth
    }

    func didActionCardView(_ sender: UIView) {
//        guard let brandCardItem = brandCardItem else { return }
//        delegate?.carouselItem(self, didSelect: brandCardItem)
    }

    func cardViewShouldShowSelectionState(_ cardView: UIView) -> Bool {
        return true
    }
}
