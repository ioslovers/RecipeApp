//
//  ColesTheme.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import UIKit
import Theme

public class ColesTheme: Appearance {
    public var color: Colors = ColesColors()
    public var font: Font = ColesFonts()
}

private struct ColesColors: Colors {
    var basicColor: BasicColors = ColesBasicColors()
}

private struct ColesFonts: Font {
    var basicFont: BasicFonts = ColesBasicFont()
}

private struct ColesBasicColors: BasicColors {
    var title = darkModeSupportedColor(UIColor.black)
    var subtitle = darkModeSupportedColor(UIColor.gray)
    var description = darkModeSupportedColor(UIColor.black)
    var body = UIColor.red
    
    // Function to detect Dark mode and return supported color
    static func darkModeSupportedColor(_ color: UIColor) -> UIColor {
        UIColor.init { (trait) -> UIColor in
            switch color {
            case .black:
                return trait.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
            default:
                return trait.userInterfaceStyle == .dark ? UIColor.yellow : UIColor.gray
            }
        }
    }
}

private struct ColesBasicFont: BasicFonts {
    var body = UIFont.preferredFont(forTextStyle: .body)
    var title = UIFont.preferredFont(forTextStyle: .largeTitle)
    var subtitle = UIFont.preferredFont(forTextStyle: .headline)
    var description = UIFont.preferredFont(forTextStyle: .footnote)
    //var title = UIFont.preferredFont(forTextStyle: .largeTitle)
//    var title = UIFont.systemFont(ofSize: 30, weight: .bold)
//    var subtitle = UIFont.systemFont(ofSize: 17, weight: .bold)
//    var description = UIFont.preferredFont(forTextStyle: .footnote)
}
