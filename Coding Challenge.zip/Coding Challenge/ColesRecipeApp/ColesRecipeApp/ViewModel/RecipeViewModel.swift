//
//  RecipeViewModel.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 1/4/2023.
//

import Foundation
import RecipeDomain
import Combine

protocol ViewPublisher: AnyObject {
    func reloadViewWithModel()
}

class RecipesViewModel: ObservableObject {
    var recipeModel: RecipeModel?
    weak var delegate: ViewPublisher?

    private var source: RecipeSource?
    private var cancellables = Set<AnyCancellable>()

    init(source: RecipeSource){
        self.source = source
    }

    func loadRecipes() {
        let input = RecipesInputSource(
            fileName: "recipesSample",
            fileExtension: "json"
        )
        source?.parseJSON(input)
            .sink { completion in
                debugPrint(completion)
            } receiveValue: { [weak self] model in
                guard let self = self else { return }
                debugPrint(model)
                self.recipeModel = self.selectFirstRecipe(in: model)
                self.delegate?.reloadViewWithModel()     
            }.store(in: &cancellables)
    }
    
    func selectFirstRecipe(in recipeModel: RecipeModel) -> RecipeModel {
        var newRecipeModel = recipeModel
        for i in 0..<(recipeModel.recipes.count ) {
            newRecipeModel.recipes[i].isSelected = (i == 0)
        }
        
        return newRecipeModel
    }
    
    func selectedIndexOfRecipe(index: Int) {
        var newRecipeModel = recipeModel
        if let recipes = recipeModel?.recipes {
            for i in 0..<recipes.count {
                newRecipeModel?.recipes[i].isSelected = (i == index)
            }
        }
        self.recipeModel = newRecipeModel
        delegate?.reloadViewWithModel()
    }
}

struct RecipesInputSource: RecipeDataInputSource {
    typealias Response = RecipeModel
    var fileName: String
    var fileExtension: String
    
    init(fileName: String, fileExtension: String) {
        self.fileName = fileName
        self.fileExtension = fileExtension
    }
    
    func decode(_ data: Data) throws -> RecipeModel {
        let decoder = JSONDecoder()
        do {
            let model = try decoder.decode(Response.self, from: data)
            return model
        } catch {
            throw error
        }
    }
}
