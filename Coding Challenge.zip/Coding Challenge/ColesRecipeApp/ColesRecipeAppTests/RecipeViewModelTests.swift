//
//  RecipeViewModelTests.swift
//  ColesRecipeAppTests
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import XCTest
import RecipeDomain
import Combine

@testable import ColesRecipeApp

class MockViewPublisher: ViewPublisher {
    var isReloadViewWithModelCalled = false
    
    func reloadViewWithModel() {
        isReloadViewWithModelCalled = true
    }
}

class RecipesViewModelTests: XCTestCase {
    var viewModel: RecipesViewModel!
    var mockSource: MockRecipeSource!
    var mockViewPublisher: MockViewPublisher!
    
    override func setUpWithError() throws {
        mockSource = MockRecipeSource()
        viewModel = RecipesViewModel(source: mockSource)
        mockViewPublisher = MockViewPublisher()
        viewModel.delegate = mockViewPublisher
    }
    
    func testLoadRecipes() throws {
        // Given
        let expectedModel = RecipeModel(
            recipes: [
            Recipe(
                dynamicTitle: "Recipe 1",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
            Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
            Recipe(
                dynamicTitle: "Recipe 3",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
        ]
        )
        mockSource.mockModel = expectedModel
        
        // When
        viewModel.loadRecipes()
        
        // Then
        XCTAssertEqual(viewModel.recipeModel?.recipes.count, expectedModel.recipes.count)
        XCTAssertTrue(mockViewPublisher.isReloadViewWithModelCalled)
    }
    
    func testSelectFirstRecipe() throws {
        // Given
        let recipe1 = Recipe(
            dynamicTitle: "Recipe 1",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ],
            isSelected: true
        )
            let recipe2 = Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ],
                isSelected: false
            )
        let recipe3 = Recipe(
            dynamicTitle: "Recipe 3",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ],
            isSelected: false
        )
        let model = RecipeModel(recipes: [recipe1, recipe2, recipe3])
        
        // When
        let result = viewModel.selectFirstRecipe(in: model)
        
        // Then
        XCTAssertTrue(result.recipes[0].isSelected!)
        XCTAssertFalse(result.recipes[1].isSelected!)
        XCTAssertFalse(result.recipes[2].isSelected!)
    }
    
    func testSelectedIndexOfRecipe() throws {
        // Given
        let recipe1 = Recipe(
            dynamicTitle: "Recipe 1",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ]
        )
        let recipe2 = Recipe(
            dynamicTitle: "Recipe 2",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ]
        )
            let recipe3 = Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            )
        let model = RecipeModel(recipes: [recipe1, recipe2, recipe3])
        viewModel.recipeModel = model
        
        // When
        viewModel.selectedIndexOfRecipe(index: 1)
        
        // Then
        XCTAssertTrue(viewModel.recipeModel?.recipes[0].isSelected == false)
        XCTAssertTrue(viewModel.recipeModel?.recipes[1].isSelected == true)
        XCTAssertTrue(viewModel.recipeModel?.recipes[2].isSelected == false)
        XCTAssertTrue(mockViewPublisher.isReloadViewWithModelCalled)
    }
}

class MockRecipeSource: RecipeSource {
    var mockModel: RecipeModel?
    func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError> {
        let future = Future<T.Response, RecipeError> { promise in
            if let model = self.mockModel as? T.Response {
                promise(.success(model))
            } else {
                promise(.failure(RecipeError.decodingError))
            }
        }
        return future
    }
}
