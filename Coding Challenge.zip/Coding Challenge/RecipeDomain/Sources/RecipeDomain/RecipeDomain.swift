//
//  File.swift
//  RecipeDomain
//
//  Created by Ashish Tripathi on 02/4/2023.
//

import Foundation
import Combine
public protocol RecipeSource: AnyObject {
    func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError>
}

public enum RecipeError: Error {
    case fileNotFound
    case decodingError
}

// MARK: - RecipeModel
public struct RecipeModel: Codable {
    public var recipes: [Recipe]
    public init(recipes: [Recipe]) {
        self.recipes = recipes
    }
}

// MARK: - Recipe
public struct Recipe: Codable {
    public let dynamicTitle: String
    public let dynamicDescription: String
    public var dynamicThumbnail: String
    public let dynamicThumbnailAlt: String
    public let recipeDetails: RecipeDetails
    public let ingredients: [Ingredient]
    public var isSelected: Bool?
    
    public init(
        dynamicTitle: String,
        dynamicDescription: String,
        dynamicThumbnail: String,
        dynamicThumbnailAlt: String,
        recipeDetails: RecipeDetails,
        ingredients: [Ingredient],
        isSelected: Bool? = false
    ) {
        self.dynamicTitle = dynamicTitle
        self.dynamicDescription = dynamicDescription
        self.dynamicThumbnail = dynamicThumbnail
        self.dynamicThumbnailAlt = dynamicThumbnailAlt
        self.recipeDetails = recipeDetails
        self.ingredients = ingredients
        self.isSelected = isSelected
    }
}

// MARK: - Ingredient
public struct Ingredient: Codable {
    public let ingredient: String
    public init(ingredient: String) {
        self.ingredient = ingredient
    }
}

// MARK: - RecipeDetails
public struct RecipeDetails: Codable {
    public let amountLabel: String
    public let amountNumber: Int
    public let prepLabel: String
    public let prepTime: String
    public let prepNote: String?
    public let cookingLabel: String
    public let cookingTime: String
    public let cookTimeAsMinutes: Int
    public let prepTimeAsMinutes: Int
    
    public init(
        amountLabel: String,
        amountNumber: Int,
        prepLabel: String,
        prepTime: String,
        prepNote: String?,
        cookingLabel: String,
        cookingTime: String,
        cookTimeAsMinutes: Int,
        prepTimeAsMinutes: Int
    ) {
        self.amountLabel = amountLabel
        self.amountNumber = amountNumber
        self.prepLabel = prepLabel
        self.prepTime = prepTime
        self.prepNote = prepNote
        self.cookingLabel = cookingLabel
        self.cookingTime = cookingTime
        self.cookTimeAsMinutes = cookTimeAsMinutes
        self.prepTimeAsMinutes = prepTimeAsMinutes
    }
}


public protocol RecipeDataInputSource {
    associatedtype Response
    var fileName: String { get set }
    var fileExtension: String { get set }
    func decode(_ data: Data) throws -> Response
}

public class RecipeDomain: RecipeSource {
    public init() {}
    public func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError> {
        return Future { promise in
            guard let url = Bundle.module.url(forResource: input.fileName, withExtension: input.fileExtension) else {
                promise(.failure(.fileNotFound))
                return
            }
            do {
                let data = try Data(contentsOf: url, options: .mappedIfSafe)
                promise(.success(try input.decode(data)))
            } catch {
                promise(.failure(.decodingError))
            }
        }
    }
}
