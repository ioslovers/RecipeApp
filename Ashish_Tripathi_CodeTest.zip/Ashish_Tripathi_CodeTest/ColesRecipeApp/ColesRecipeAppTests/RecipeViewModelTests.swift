//
//  RecipeViewModelTests.swift
//  ColesRecipeAppTests
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import XCTest
import RecipeDomain
import Combine

@testable import ColesRecipeApp

class MockViewPublisher: ViewPublisher {
    var errorMessage: String?
    var isShowDataOnView = false

    func showDataOnView() {
        isShowDataOnView = true
    }

    func showError(message: String) {
        errorMessage = message
    }
}

class RecipesViewModelTests: XCTestCase {
    var viewModel: RecipesViewModel!
    var mockSource: MockRecipeSource!
    var mockViewPublisher: MockViewPublisher!
    
    override func setUpWithError() throws {
        mockSource = MockRecipeSource()
        viewModel = RecipesViewModel(source: mockSource)
        mockViewPublisher = MockViewPublisher()
        viewModel.delegate = mockViewPublisher
    }
    
    func testLoadRecipes() {
        // Given
        let expectedModel = RecipeModel(
            recipes: [
            Recipe(
                dynamicTitle: "Recipe 1",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
            Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
            Recipe(
                dynamicTitle: "Recipe 3",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            ),
        ]
        )
        mockSource.mockModel = expectedModel
        
        // When
        viewModel.loadRecipes()
        
        // Then
        XCTAssertEqual(viewModel.recipeModel?.recipes.count, expectedModel.recipes.count)
        XCTAssertTrue(mockViewPublisher.isShowDataOnView)
    }
    
    func testSelectFirstRecipe() {
        // Given
        let recipe1 = Recipe(
            dynamicTitle: "Recipe 1",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ],
            isSelected: true
        )
            let recipe2 = Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ],
                isSelected: false
            )
        let recipe3 = Recipe(
            dynamicTitle: "Recipe 3",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ],
            isSelected: false
        )
        let model = RecipeModel(recipes: [recipe1, recipe2, recipe3])
        
        // When
        let result = viewModel.selectFirstRecipe(in: model)
        
        // Then
        XCTAssertTrue(result.recipes[0].isSelected!)
        XCTAssertFalse(result.recipes[1].isSelected!)
        XCTAssertFalse(result.recipes[2].isSelected!)
    }
    
    func testSelectedIndexOfRecipe() {
        // Given
        let recipe1 = Recipe(
            dynamicTitle: "Recipe 1",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ]
        )
        let recipe2 = Recipe(
            dynamicTitle: "Recipe 2",
            dynamicDescription: "",
            dynamicThumbnail: "",
            dynamicThumbnailAlt: "",
            recipeDetails: RecipeDetails(
                amountLabel: "",
                amountNumber: 0,
                prepLabel: "",
                prepTime: "",
                prepNote: nil,
                cookingLabel: "",
                cookingTime: "",
                cookTimeAsMinutes: 0,
                prepTimeAsMinutes: 0
            ),
            ingredients: [
                Ingredient(
                    ingredient: ""
                )
            ]
        )
            let recipe3 = Recipe(
                dynamicTitle: "Recipe 2",
                dynamicDescription: "",
                dynamicThumbnail: "",
                dynamicThumbnailAlt: "",
                recipeDetails: RecipeDetails(
                    amountLabel: "",
                    amountNumber: 0,
                    prepLabel: "",
                    prepTime: "",
                    prepNote: nil,
                    cookingLabel: "",
                    cookingTime: "",
                    cookTimeAsMinutes: 0,
                    prepTimeAsMinutes: 0
                ),
                ingredients: [
                    Ingredient(
                        ingredient: ""
                    )
                ]
            )
        let model = RecipeModel(recipes: [recipe1, recipe2, recipe3])
        viewModel.recipeModel = model
        
        // When
        viewModel.selectedIndexOfRecipe(index: 1)
        
        // Then
        XCTAssertTrue(viewModel.recipeModel?.recipes[0].isSelected == false)
        XCTAssertTrue(viewModel.recipeModel?.recipes[1].isSelected == true)
        XCTAssertTrue(viewModel.recipeModel?.recipes[2].isSelected == false)
        XCTAssertTrue(mockViewPublisher.isShowDataOnView)
    }
    
    func testDomainString() {
        let path = "/recipes"
        let expectedDomainString = "https://www.coles.com.au\(path)"
        
        XCTAssertEqual(path.domainString, expectedDomainString)
    }
    
    func testHandleErrors_DecodingError() {
        let decodingError = RecipeError.decodingError
        let expectedMessage = "Failed to load the JSON error: \(decodingError.localizedDescription)"
        
        let mockDelegate = MockViewPublisher()
        viewModel.delegate = mockDelegate
        
        viewModel.handleErrors(for: decodingError)
        
        XCTAssertEqual(mockDelegate.errorMessage, expectedMessage)
    }
    
    func testHandleErrors_FileNotFoundError() {
        let fileNotFoundError = RecipeError.fileNotFound
        let expectedMessage = "File not found error: \(fileNotFoundError.localizedDescription)"
        
        let mockDelegate = MockViewPublisher()
        viewModel.delegate = mockDelegate
        
        viewModel.handleErrors(for: fileNotFoundError)
        
        XCTAssertEqual(mockDelegate.errorMessage, expectedMessage)
    }
}

class MockRecipeSource: RecipeSource {
    var mockModel: RecipeModel?
    func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError> {
        let future = Future<T.Response, RecipeError> { promise in
            if let model = self.mockModel as? T.Response {
                promise(.success(model))
            } else {
                promise(.failure(RecipeError.decodingError))
            }
        }
        return future
    }
}
