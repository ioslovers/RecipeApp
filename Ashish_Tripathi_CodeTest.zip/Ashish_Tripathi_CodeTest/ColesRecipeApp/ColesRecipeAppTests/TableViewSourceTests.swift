//
//  ColesRecipeAppTests.swift
//  ColesRecipeAppTests
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import XCTest
@testable import ColesRecipeApp

class TableViewSourceTests: XCTestCase {
    
    func testTableViewSources() {
        let sources = [recipeDetailsSource, prepViewCellSource, itemListCellsource, gridTableViewCellsource]
        
        for source in sources {
            // Check that the identifier string is not empty
            XCTAssertFalse(source.identifier.rawValue.isEmpty, "Invalid identifier for TableViewSource: \(source)")
            
            // Check that the section is not nil
            XCTAssertNotNil(source.section, "Invalid cell class for TableViewSource: \(source)")
        }
    }
}
