//
//  ColesRecipeAppUITests.swift
//  ColesRecipeAppUITests
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import XCTest

final class ColesRecipeAppUITests: XCTestCase {
    func testAppScrolling() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
    
        let tablesQuery = app.tables
        let imageIdentifierImage = tablesQuery.images["image_identifier"]
        imageIdentifierImage.swipeUp()
    }
    
    func testRecipeSelection() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        
        let tablesQuery = app.tables
        let imageIdentifierImage = tablesQuery.images["image_identifier"]
        imageIdentifierImage.swipeUp()
        tablesQuery.cells["recipe_id_1"].tap()
    }
    
    func testRecipeScrolling() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()
        
        let tablesQuery = XCUIApplication().tables
        tablesQuery.images["image_identifier"].swipeUp()
        let element = tablesQuery.cells["recipe_id_1"].children(matching: .other).element.children(matching: .other).element
        element.swipeLeft()
    }
}
