//
//  RecipeViewModel.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import RecipeDomain
import Combine
import UIKit

protocol ViewPublisher: AnyObject {
    func showDataOnView()
    func showError(message: String)
}

final class RecipesViewModel: ObservableObject {
    // MARK: - variables
    
    var recipeModel: RecipeModel?
    weak var delegate: ViewPublisher?
    var recipeViewControllerSource: RecipeTableViewControllerSource = allSourcesForPort
    
    // MARK: - Private variables
    
    private var source: RecipeSource?
    private var cancellables = Set<AnyCancellable>()

    // MARK: - init
    init(source: RecipeSource){
        self.source = source
    }
    
    // MARK: - Functions
    func loadRecipes() {
        let input = RecipesInputSource(
            fileName: "recipesSample",
            fileExtension: "json"
        )
        source?.parseJSON(input)
            .sink { [weak self] completion in
                switch completion {
                case .finished:
                    debugPrint("completion is finished, we got success response")
                case let .failure(error):
                    self?.handleErrors(for: error)
                }
            } receiveValue: { [weak self] model in
                guard let self = self else { return }
                self.recipeModel = self.selectFirstRecipe(in: model)
                self.delegate?.showDataOnView()
            }.store(in: &cancellables)
    }
    
    func selectFirstRecipe(in recipeModel: RecipeModel) -> RecipeModel {
        var newRecipeModel = recipeModel
        newRecipeModel.recipes.indices.forEach { newRecipeModel.recipes[$0].isSelected = $0 == 0 }
        return newRecipeModel
    }
    
    func selectedIndexOfRecipe(index: Int) {
        var newRecipeModel = recipeModel
        if let recipes = recipeModel?.recipes {
            for i in 0..<recipes.count {
                newRecipeModel?.recipes[i].isSelected = (i == index)
            }
        }
        self.recipeModel = newRecipeModel
        delegate?.showDataOnView()
    }
    
    func setViewControllerSource(deviceOrientation: UIDeviceOrientation) {
        if deviceOrientation.isPortrait {
            recipeViewControllerSource = allSourcesForPort
        } else if deviceOrientation.isLandscape {
            recipeViewControllerSource = allSourcesForLandscape
        }
    }
    
    func handleErrors(for error: RecipeError) {
        var message = "Unknown Error: \(error)"
        switch error {
        case .decodingError:
            message = "Failed to load the JSON error: \(error.localizedDescription)"
        case .fileNotFound:
            message = "File not found error: \(error.localizedDescription)"
        }
        delegate?.showError(message: message)
    }
}
