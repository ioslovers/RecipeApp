//
//  ColesTheme.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import UIKit
import Theme

public enum ColesStandardPadding {
    enum LineNumbers: Int {
        case zero = 0
    }
    enum Spacing: Int {
        case padding = 0
    }
    enum Sizes: CGFloat {
        case cellHeight = 290.0
        case cellWidth = 240.0
    }
}

public final class ColesTheme: Appearance {
    public var color: Colors = ColesColors()
    public var font: Font = ColesFonts()
}

private struct ColesColors: Colors {
    var basicColor: BasicColors = ColesBasicColors()
}

private struct ColesFonts: Font {
    var basicFont: BasicFonts = ColesBasicFont()
}

private struct ColesBasicColors: BasicColors {
    var title = darkModeSupportedColor(UIColor.black)
    var subtitle = darkModeSupportedColor(UIColor.gray)
    var description = darkModeSupportedColor(UIColor.black)
    var body = UIColor.red
    
    // Function to detect Dark mode and return supported color
    static func darkModeSupportedColor(_ color: UIColor) -> UIColor {
        UIColor.init { (trait) -> UIColor in
            switch color {
            case .black:
                return trait.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
            default:
                return trait.userInterfaceStyle == .dark ? UIColor.yellow : UIColor.gray
            }
        }
    }
}

private struct ColesBasicFont: BasicFonts {
    var body = UIFont.preferredFont(forTextStyle: .body)
    var title = UIFont.preferredFont(forTextStyle: .largeTitle)
    var subtitle = UIFont.preferredFont(forTextStyle: .headline)
    var description = UIFont.preferredFont(forTextStyle: .footnote)
}
