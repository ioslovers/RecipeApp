//
//  String.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation

extension String {
    var domainString: String {
        return "https://www.coles.com.au".appending(self)
    }
}
