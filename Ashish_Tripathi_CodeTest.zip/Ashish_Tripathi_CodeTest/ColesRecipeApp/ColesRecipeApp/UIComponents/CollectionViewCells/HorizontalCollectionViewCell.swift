//
//  HorizontalCollectionViewCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 02/4/2023.
//

import UIKit
import Theme

protocol HorizontalCollectionViewDataSource {
    var title: String { get set}
    var description: String { get set}
    var imageUrl: String { get set}
}

final class HorizontalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        setupStyle()
    }

    /// SetupStyle for colors, font
    func setupStyle() {
        titleLabel.textColor = Theme.appearance.color.basicColor.body
        descriptionLabel.textColor = Theme.appearance.color.basicColor.description
        
        titleLabel.font = Theme.appearance.font.basicFont.body
        descriptionLabel.font = Theme.appearance.font.basicFont.body
        
        titleLabel.setLabelBasicStyle()
        descriptionLabel.setLabelBasicStyle()
        titleLabel.isAccessibilityElement = false
        descriptionLabel.isAccessibilityElement = false
        imageView.isAccessibilityElement = false

        layer.cornerRadius = 10
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.lightGray.cgColor
    }

    func bind(source: HorizontalCollectionViewDataSource) {
        imageView.loadThumbnail(urlSting: source.imageUrl)
        titleLabel.text = NSLocalizedString("RECIPE", comment: "")
        descriptionLabel.text = source.title
    }
}
