//
//  RecipeTableView.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit

final class RecipeTableView: UITableView {
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        setupTableView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupTableView()
    }
    
    private func setupTableView() {
        separatorColor = .clear
        separatorStyle = .none
        backgroundColor = .white
        sectionHeaderTopPadding = 0
        registerCells()
    }

    private func registerCells() {
        register(
            UINib(
                nibName: TableViewCells.recipeDetailsCell.rawValue,
                bundle: nil
            ),
            forCellReuseIdentifier: TableViewCells.recipeDetailsCell.rawValue
        )
        register(
            UINib(
                nibName: TableViewCells.prepViewCell.rawValue,
                bundle: nil
            ),
            forCellReuseIdentifier: TableViewCells.prepViewCell.rawValue
        )
        register(
            UINib(
                nibName: TableViewCells.itemListCell.rawValue,
                bundle: nil
            ),
            forCellReuseIdentifier: TableViewCells.itemListCell.rawValue
        )
        register(
            UINib(
                nibName: TableViewCells.gridTableViewCell.rawValue,
                bundle: nil
            ),
            forCellReuseIdentifier: TableViewCells.gridTableViewCell.rawValue)
    }
}
