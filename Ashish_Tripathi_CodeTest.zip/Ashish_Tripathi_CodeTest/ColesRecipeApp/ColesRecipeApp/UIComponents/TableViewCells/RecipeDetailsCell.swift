//
//  RecipeDetailsCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit
import RecipeDomain
import Theme

protocol RecipeDetailsDataSource {
    var recipe: Recipe { get set }
}

final class RecipeDetailsCell: UITableViewCell, ReusableElementCell {
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var recipeImageView: UIImageView!

    override public func awakeFromNib() {
        super.awakeFromNib()
        setStyle()
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    /// SetupStyle for colors, font
    private func setStyle() {
        headingLabel.textColor = Theme.appearance.color.basicColor.title
        descriptionLabel.textColor = Theme.appearance.color.basicColor.description
        
        descriptionLabel.font = Theme.appearance.font.basicFont.body
        descriptionLabel.setLabelBasicStyle()
        
        headingLabel.font = Theme.appearance.font.basicFont.title
        headingLabel.setLabelBasicStyle()
        accessibilityElements = [headingLabel, descriptionLabel, recipeImageView].compactMap{$0}
    }

    /// bind data source of the cell
    func bind(source: CellTypeValueSource) {
        headingLabel.text = source.recipe.dynamicTitle
        descriptionLabel.text = source.recipe.dynamicDescription
        recipeImageView.loadThumbnail(urlSting: source.recipe.dynamicThumbnail.domainString)
    }
}

struct ItemListValues: ItemListDataSource {
    var itemList: [String]? = []

    init(list: [Ingredient]) {
        list.forEach { item in
            self.itemList?.append(item.ingredient)
        }
    }
}
