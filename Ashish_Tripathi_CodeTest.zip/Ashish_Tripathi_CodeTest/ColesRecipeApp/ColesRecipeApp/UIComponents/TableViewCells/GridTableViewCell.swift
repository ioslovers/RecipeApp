//
//  HGridTableViewCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit
import RecipeDomain

protocol GridTableViewCellDelegate: AnyObject {
    func selectedIndexOfRecipe(index: Int)
}

final class GridTableViewCell: UITableViewCell, ReusableElementCell {
    @IBOutlet weak var collectionView: UICollectionView!
    weak var delegate: GridTableViewCellDelegate?
    private var recipes: [Recipe]?

    override func awakeFromNib() {
        super.awakeFromNib()
        registerCell()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = GridCollectionViewFlowLayout()
    }
    
    private func registerCell() {
        collectionView.register(
            UINib(
                nibName:"HorizontalCollectionViewCell",
                bundle: nil
            ),forCellWithReuseIdentifier: "HorizontalCollectionViewCell"
        )
    }

    /// bind data source of the cell
    func bind(source: CellTypeValueSource) {
        recipes = source.cellElementModelSecondary?.recipeList
        collectionView.reloadData()
        delegate = source.cellElementModelSecondary?.delegate
    }
}

extension GridTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(
        _ collectionView: UICollectionView,
        numberOfItemsInSection section: Int
    ) -> Int {
        recipes?.count ?? 0
    }

    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "HorizontalCollectionViewCell",
            for: indexPath) as! HorizontalCollectionViewCell
        if let recipe = recipes?[indexPath.row] {
            cell.bind(source: HorizontalCollectionViewDataValue(recipe: recipe))
            cell.isAccessibilityElement = true
            cell.accessibilityLabel = recipe.dynamicTitle
            cell.accessibilityIdentifier = "recipe_id_\(indexPath.row)"
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.selectedIndexOfRecipe(index: indexPath.row)
    }
}

struct HorizontalCollectionViewDataValue: HorizontalCollectionViewDataSource {
    var title: String
    var description: String
    var imageUrl: String

    init(recipe: Recipe) {
        self.title = recipe.dynamicTitle
        self.description = recipe.dynamicDescription
        self.imageUrl = recipe.dynamicThumbnail.domainString
    }
}

private final class GridCollectionViewFlowLayout: UICollectionViewFlowLayout {
    override init() {
        super.init()
        self.setupFlowLayout()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    /// setup flow layout
    private func setupFlowLayout() {
        scrollDirection = .horizontal
        itemSize = CGSize(
            width: ColesStandardPadding.Sizes.cellWidth.rawValue,
            height: ColesStandardPadding.Sizes.cellHeight.rawValue
        )
    }
}
