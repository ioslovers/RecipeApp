//
//  PrepViewCell.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit
import RecipeDomain
import Theme

final class PrepViewCell: UITableViewCell, ReusableElementCell {
    @IBOutlet weak var firstTitleLabel: UILabel!
    @IBOutlet weak var firstValueLabel: UILabel!
    @IBOutlet weak var secondTitleLabel: UILabel!
    @IBOutlet weak var secondValueLabel: UILabel!
    @IBOutlet weak var thirdTitleLabel: UILabel!
    @IBOutlet weak var thirdValueLabel: UILabel!
    
    // MARK: - Initialization
    override public func awakeFromNib() {
        super.awakeFromNib()
        setupStyle()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    /// SetupStyle for colors, font
    private func setupStyle() {
        firstTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        secondTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        thirdTitleLabel.textColor = Theme.appearance.color.basicColor.subtitle
        
        firstValueLabel.textColor = Theme.appearance.color.basicColor.description
        secondValueLabel.textColor = Theme.appearance.color.basicColor.description
        thirdValueLabel.textColor = Theme.appearance.color.basicColor.description
        
        firstTitleLabel.font = Theme.appearance.font.basicFont.body
        secondTitleLabel.font = Theme.appearance.font.basicFont.body
        thirdTitleLabel.font = Theme.appearance.font.basicFont.body
        
        firstValueLabel.font = Theme.appearance.font.basicFont.subtitle
        secondValueLabel.font = Theme.appearance.font.basicFont.subtitle
        thirdValueLabel.font = Theme.appearance.font.basicFont.subtitle
    }
    
    /// bind data source of the cell
    func bind(source: CellTypeValueSource) {
        firstTitleLabel.text = source.recipe.recipeDetails.amountLabel
        firstValueLabel.text = "\(source.recipe.recipeDetails.amountNumber)"
        secondTitleLabel.text = source.recipe.recipeDetails.prepLabel
        secondValueLabel.text = source.recipe.recipeDetails.prepTime
        thirdTitleLabel.text = source.recipe.recipeDetails.cookingLabel
        thirdValueLabel.text = source.recipe.recipeDetails.cookingTime
    }
}
