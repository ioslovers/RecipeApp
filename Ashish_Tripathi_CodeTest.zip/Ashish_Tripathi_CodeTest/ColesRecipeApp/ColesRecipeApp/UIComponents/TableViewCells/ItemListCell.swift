//
//  IngredientsListView.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit
import Theme

protocol ItemListDataSource {
    var itemList: [String]? { get set }
}

final class ItemListCell: UITableViewCell, ReusableElementCell {
    @IBOutlet weak var itemHeaderLabel: UILabel!
    @IBOutlet weak var itemStackView: UIStackView!
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        setStyle()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    /// SetupStyle for colors, font
    private func setStyle() {
        itemHeaderLabel.font = Theme.appearance.font.basicFont.title
        itemHeaderLabel.textColor = Theme.appearance.color.basicColor.title
        itemStackView.isAccessibilityElement = false
        itemHeaderLabel.isAccessibilityElement = true
    }
    
    /// bind data source of the cell
    func bind(source: CellTypeValueSource) {
        itemHeaderLabel.text = NSLocalizedString("Ingredients", comment: "")
        itemStackView.subviews.forEach { $0.removeFromSuperview() }
        var accessibilityId = 0
        let labels = source.recipe.ingredients.map {
            accessibilityId += 1
            let label = UILabel(frame: .zero)
            label.textColor = Theme.appearance.color.basicColor.description
            label.font = Theme.appearance.font.basicFont.body
            label.numberOfLines = ColesStandardPadding.LineNumbers.zero.rawValue
            label.adjustsFontForContentSizeCategory = true
            label.translatesAutoresizingMaskIntoConstraints = false
            label.setContentHuggingPriority(.required, for: .vertical)
            label.isAccessibilityElement = true
            label.accessibilityIdentifier = "indredient_label_\(accessibilityId)"
            label.accessibilityLabel = $0.ingredient
            label.text = ">  \($0.ingredient)"
            return label
        }

        labels.forEach {
            itemStackView.addArrangedSubview($0)
        }
    }
}
