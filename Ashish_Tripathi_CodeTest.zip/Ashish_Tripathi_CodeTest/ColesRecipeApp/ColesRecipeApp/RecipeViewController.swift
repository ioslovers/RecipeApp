//
//  RecipeViewController.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import UIKit
import RecipeDomain

final class RecipeViewController: UIViewController {
    @IBOutlet weak var tableView: RecipeTableView!

    private let viewModel = RecipesViewModel(source: RecipeDomain())
    private var cellTypeValueSource: CellTypeValueSource?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup View
        setupView()
        
        // ViewModel setup
        viewModel.delegate = self
        viewModel.loadRecipes()
    }

    override func viewDidLayoutSubviews() {
        viewModel.setViewControllerSource(
            deviceOrientation: UIDevice.current.orientation
        )
        tableView.reloadData()
    }

    private func setupView() {
        tableView.separatorColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension RecipeViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        viewModel.recipeViewControllerSource.tableSource.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let recipeList = viewModel.recipeModel?.recipes,
              let recipe = recipeList.first(where: { $0.isSelected ?? false }),
              let cellSource = viewModel.recipeViewControllerSource.tableSource[safe: indexPath.section],
              let identifier = TableViewCells(rawValue: cellSource.identifier.rawValue)
        else {
            return UITableViewCell()
        }
        
        return cellFor(
            tableView: tableView,
            cellTypeValue: CellTypeValueSource(
                cellType: identifier,
                recipe: recipe,
                cellElementModelSecondary: CellElementModelValue(recipeList: recipeList)
            ),
            at: indexPath
        )
    }
    
    private func cellFor(tableView: UITableView, cellTypeValue: CellTypeValueSource, at indexPath: IndexPath) -> UITableViewCell {
        cellTypeValueSource = cellTypeValue
        guard let cellIdentifier = cellTypeValueSource?.cellType.rawValue,
              let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? ReusableElementCell & UITableViewCell
        else {
            return UITableViewCell()
        }
        
        if cellTypeValueSource?.cellType == .gridTableViewCell {
            cellTypeValueSource?.cellElementModelSecondary?.delegate = self
        }
        
        cell.bind(source: cellTypeValueSource!)
        return cell
    }
}

extension RecipeViewController: GridTableViewCellDelegate {
    func selectedIndexOfRecipe(index: Int) {
        viewModel.selectedIndexOfRecipe(index: index)
        tableView.scrollToRow(
            at: IndexPath(row: 0, section: 0),
            at: .top,
            animated: true
        )
    }
}

extension RecipeViewController: ViewPublisher {
    func showDataOnView() {
        tableView.reloadData()
    }
    
    func showError(message: String) {
        let alert = Alert(subTitle: message, cancelTitle: "Ok")
        alert.presentAlert(from: self)
    }
}

extension Collection {
    subscript (safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
