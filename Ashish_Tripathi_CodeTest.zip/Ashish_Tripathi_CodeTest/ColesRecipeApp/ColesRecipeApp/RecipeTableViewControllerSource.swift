//
//  RecipeTableViewControllerSource.swift
//  ColesRecipeApp
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import UIKit
import RecipeDomain

enum TableViewCells: String {
    case recipeDetailsCell = "RecipeDetailsCell"
    case prepViewCell = "PrepViewCell"
    case itemListCell = "ItemListCell"
    case gridTableViewCell = "GridTableViewCell"
}

protocol ReusableElementCell: AnyObject {
    func bind(source: CellTypeValueSource)
}

protocol CellElementModel {
    var cellType: TableViewCells { get set }
    var recipe: Recipe { get set }
    var cellElementModelSecondary: CellElementModelValue? { get set }
}

protocol CellElementModelSecondary {
    var recipeList: [Recipe] { get set }
    var delegate: GridTableViewCellDelegate? { get set }
}

struct CellTypeValueSource: RecipeDetailsDataSource, CellElementModel {
    var cellType: TableViewCells
    var recipe: Recipe
    var cellElementModelSecondary: CellElementModelValue?
}

struct CellElementModelValue: CellElementModelSecondary {
    var delegate: GridTableViewCellDelegate?
    var recipeList: [Recipe]
}

struct RecipeTableViewControllerSource {
    let tableSource: [TableViewSource]
}

struct TableViewSource {
    let section: Int
    let identifier: TableViewCells
}

let recipeDetailsSource = TableViewSource(
    section: 0,
    identifier: TableViewCells.recipeDetailsCell
)

let prepViewCellSource = TableViewSource(
    section: 1,
    identifier: TableViewCells.prepViewCell
)

let itemListCellsource = TableViewSource(
    section: 2,
    identifier: TableViewCells.itemListCell
)

let gridTableViewCellsource = TableViewSource(
    section: 3,
    identifier: TableViewCells.gridTableViewCell
)

let allSourcesForPort = RecipeTableViewControllerSource(
    tableSource: [
        recipeDetailsSource,
        prepViewCellSource,
        itemListCellsource,
        gridTableViewCellsource
    ]
)

let allSourcesForLandscape = RecipeTableViewControllerSource(
    tableSource: [
        gridTableViewCellsource
    ]
)
