# ColesRecipeApp

A ColesRecipeApp is showing recipes using the `RecipeDomain`. 
App is using `UIKit` framework and creating a `RecipeViewController` to display all the recipes.
`RecipeViewController` is using `UIComponents` to display all the recipes with the help of `RecipesViewModel`.
Application is using MVVM architecture, Combine for fetching data from `RecipeDomain`.  

`UIComponents` have all the reusable components such as tableView, collectionView, and it's cells.

* Its coverd by unit test cases to showcase success and failure scenarios
* Its coverd by UI test cases



**MAC OSX Version**
```sh
13.2.1 Ventura
```

**XCode Version**
```sh
Xcode 14.2
```
**iOS Version**
```sh
Supports from iOS 15.0 onwards
```
**Swift Version**
```sh
Swift version 5
```
**App Architecture**
```sh
MVVM
```

**Third Party Library**
```sh
Not using any
```

## Task

```
I am using given file named `recipesSample.json` file to fetch its data in the application, and using articles.
-- dynamicTitle
-- dynamicDescription
-- dynamicThumbnail
-- recipeDetails
-- ingredients
```
```
App supports all sized iPhone in Portrait mode, and displaying recipe in the UITableView, and recipe list in a collectionView also tapping on the recipe refreshes tableview with the selected recipe. 
```
```

```
Additional features covered
```
```
Voice Over, large mode
Dark mode
App is automation supported with accessibilityId.
```
