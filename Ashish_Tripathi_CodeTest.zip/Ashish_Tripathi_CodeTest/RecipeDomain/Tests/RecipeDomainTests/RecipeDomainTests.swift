import XCTest
import Combine
@testable import RecipeDomain

final class RecipeDomainTests: XCTestCase {
    var cancellables = Set<AnyCancellable>()
    let recipeDomain = RecipeDomain()

    func testJsonParsingSuccess() throws {
        let expectation = expectation(description: "JSON parsing success")
        let input = RecipesInputSource(fileName: "recipesSample", fileExtension: "json")
        recipeDomain.parseJSON(input)
            .sink { completion in
                debugPrint(completion)
                switch completion {
                case .failure:
                    XCTFail("Parsing should not fail")
                case .finished:
                    expectation.fulfill()
                }
            } receiveValue: { model in
                XCTAssertNotNil(model)
            }.store(in: &cancellables)
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testParseJSONFailureFileNotFound() {
        let expectation = expectation(description: "JSON parsing failure: file not found")
        let input = RecipesInputSource(fileName: "recipesSampleXYZ", fileExtension: "json")
        recipeDomain.parseJSON(input)
            .sink { completion in
                switch completion {
                case .failure(let error):
                    if case .fileNotFound = error {
                        expectation.fulfill()
                    } else {
                        XCTFail("Parsing error should be .fileNotFound")
                    }
                case .finished:
                    XCTFail("Parsing should fail")
                }
            } receiveValue: { _ in
                XCTFail("Parsing should not succeed")
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testParseJSONFailureDecodingError() {
        let expectation = self.expectation(description: "JSON parsing failure: decoding error")
        let input = RecipesInputSource(fileName: "invalidSample", fileExtension: "json")
        recipeDomain.parseJSON(input)
            .sink { completion in
                switch completion {
                case .failure(let error):
                    if case .decodingError = error {
                        expectation.fulfill()
                    } else {
                        XCTFail("Parsing error should be .decodingError")
                    }
                case .finished:
                    XCTFail("Parsing should fail")
                }
            } receiveValue: { _ in
                XCTFail("Parsing should not succeed")
            }
            .store(in: &cancellables)
        
        waitForExpectations(timeout: 1, handler: nil)
    }
}
