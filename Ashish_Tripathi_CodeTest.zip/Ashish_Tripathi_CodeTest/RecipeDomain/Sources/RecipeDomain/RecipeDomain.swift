//
//  File.swift
//  RecipeDomain
//
//  Created by Ashish Tripathi on 2/4/2023.
//

import Foundation
import Combine

/// RecipeSource: This protocol can be extended by the implementation of load response from a .json file or networking class for future.
public protocol RecipeSource: AnyObject {
    func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError>
}

/// RecipeError: for error handling cases
public enum RecipeError: Error {
    case fileNotFound
    case decodingError
}

public protocol RecipeDataInputSource {
    associatedtype Response
    var fileName: String { get set }
    var fileExtension: String { get set }
    func decode(_ data: Data) throws -> Response
}

public final class RecipeDomain: RecipeSource {
    public init() {}
    
    /// parseJSON: to parse any type of file
    public func parseJSON<T: RecipeDataInputSource>(_ input: T) -> Future<T.Response, RecipeError> {
        return Future { promise in
            guard let url = Bundle.module.url(forResource: input.fileName, withExtension: input.fileExtension) else {
                promise(.failure(.fileNotFound))
                return
            }
            do {
                let data = try Data(contentsOf: url, options: .mappedIfSafe)
                promise(.success(try input.decode(data)))
            } catch {
                promise(.failure(.decodingError))
            }
        }
    }
}

public struct RecipesInputSource: RecipeDataInputSource {
    public typealias Response = RecipeModel
    public var fileName: String
    public var fileExtension: String
    
    public init(fileName: String, fileExtension: String) {
        self.fileName = fileName
        self.fileExtension = fileExtension
    }
    
    public func decode(_ data: Data) throws -> RecipeModel {
        let decoder = JSONDecoder()
        do {
            let model = try decoder.decode(Response.self, from: data)
            return model
        } catch {
            throw error
        }
    }
}
