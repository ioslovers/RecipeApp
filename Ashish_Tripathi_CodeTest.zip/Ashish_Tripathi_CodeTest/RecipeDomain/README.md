# RecipeDomain

A RecipeDomain is a package to fetch recipe resoponse from a provided `recipesSample.json` file

```swift
let recipeDomain = RecipeDomain()
recipeDomain.parseJSON(input)
            .sink { completion in
                // Handle comletion of it with error
            } receiveValue: { model in
                // Handle success of it with model
            }.store(in: &cancellables)
```
* This package is also have test cases to showcase success and failure scenarios 
