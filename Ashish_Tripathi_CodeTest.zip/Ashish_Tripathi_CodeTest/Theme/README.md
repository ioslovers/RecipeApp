# Theme

Theme package is to provide reusability of the branding colors and font accross the application.

```swift
// Injecting a test app theme to theme library from app delegate in the main app
        Theme.appearance = TestAppTheme()
```

* Implement Theme protocols in the app with your app name TestAppTheme
```swift
class TestAppTheme: Appearance {
    var color: Colors = TestAppColors()
    var font: Font = TestAppFonts()
}

private struct TestAppColors: Colors {
    var basicColor: BasicColors = TestAppBasicColors()
}

private struct TestAppFonts: Font {
    var basicFont: BasicFonts = TestAppBasicFont()
}

private struct TestAppBasicColors: BasicColors {
    var body = UIColor.black
    var title = UIColor.black
    var subtitle = UIColor.black
    var description = UIColor.black
}

private struct TestAppBasicFont: BasicFonts {
    var body = UIFont.preferredFont(forTextStyle: .body)
    var title = UIFont.preferredFont(forTextStyle: .body)
    var subtitle = UIFont.preferredFont(forTextStyle: .footnote)
    var description = UIFont.preferredFont(forTextStyle: .footnote)
}
```
