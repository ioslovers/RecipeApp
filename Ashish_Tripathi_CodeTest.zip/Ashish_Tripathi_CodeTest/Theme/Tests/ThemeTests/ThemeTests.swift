#if os(iOS)
import Foundation
import UIKit
import XCTest
@testable import Theme

/// TestAppTheme is to test Theme library
class TestAppTheme: Appearance {
    var color: Colors = TestAppColors()
    var font: Font = TestAppFonts()
}

private struct TestAppColors: Colors {
    var basicColor: BasicColors = TestAppBasicColors()
}

private struct TestAppFonts: Font {
    var basicFont: BasicFonts = TestAppBasicFont()
}

private struct TestAppBasicColors: BasicColors {
    var body = UIColor.black
    var title = UIColor.black
    var subtitle = UIColor.black
    var description = UIColor.black
}

private struct TestAppBasicFont: BasicFonts {
    var body = UIFont.preferredFont(forTextStyle: .body)
    var title = UIFont.preferredFont(forTextStyle: .body)
    var subtitle = UIFont.preferredFont(forTextStyle: .footnote)
    var description = UIFont.preferredFont(forTextStyle: .footnote)
}


class ThemeTests: XCTestCase {
    
    override func setUpWithError() throws {
        // Injecting a test app theme to theme library
        Theme.appearance = TestAppTheme()
    }
    
    /// TEST CASE: Testing title color from Theme library
    /// Test should pass and Theme should return black color
    func testTitleColor() throws {
        XCTAssertEqual(UIColor.black, Theme.appearance.color.basicColor.title)
    }
    
    /// TEST CASE: Testing title font from Theme library
    /// Test should pass and Theme should return body font
    func testTitleFont() throws {
        XCTAssertEqual(
            UIFont.preferredFont(forTextStyle: .body),
            Theme.appearance.font.basicFont.title
        )
    }
}
#endif
